package com.vitor.remotecolonymanager;

import com.minecolonies.api.colony.workorders.WorkOrderType;

public final class WorkOrderTypeNames {
   private WorkOrderTypeNames() {
   }

   public static String getName(WorkOrderType type) {
      return label(code(type));
   }

   /** Código compacto enviado pela rede: 0 construção, 1 melhoria, 2 reparo, 3 remoção, 4 desconhecido. */
   public static int code(WorkOrderType type) {
      if (type == null) {
         return 4;
      }
      switch (type) {
         case BUILD:
            return 0;
         case UPGRADE:
            return 1;
         case REPAIR:
            return 2;
         case REMOVE:
            return 3;
         default:
            return 4;
      }
   }

   public static String label(int code) {
      switch (code) {
         case 0:
            return "Construção";
         case 1:
            return "Melhoria";
         case 2:
            return "Reparo";
         case 3:
            return "Remoção";
         default:
            return "Desconhecido";
      }
   }
}
