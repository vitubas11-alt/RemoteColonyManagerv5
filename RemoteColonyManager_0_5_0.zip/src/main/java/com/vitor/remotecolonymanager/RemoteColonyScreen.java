package com.vitor.remotecolonymanager;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Remote Colony Manager v0.5 - painel com 3 abas: Painel (visão geral), Obras (ordens x construtores) e Prédios.
 * Tudo é desenhado manualmente; listas rolam arrastando (celular), pela barra, roda ou teclado.
 */
public class RemoteColonyScreen extends Screen {
   public static final String VERSION = "0.5.0";

   // ---------- paleta ----------
   private static final int C_BG = 0xF0121820;
   private static final int C_BORDER = 0xFF3A4656;
   private static final int C_HEAD_TOP = 0xFF2B3A52;
   private static final int C_HEAD_BOT = 0xFF1A2333;
   private static final int C_CARD = 0xFF1C2430;
   private static final int C_CARD_HOVER = 0xFF263142;
   private static final int C_CARD_SEL = 0xFF1F3B5E;
   private static final int C_GOLD = 0xFFF2B84B;
   private static final int C_TEXT = 0xFFE6EDF3;
   private static final int C_DIM = 0xFF8B97A6;
   private static final int C_GREEN = 0xFF56C271;
   private static final int C_RED = 0xFFE5594F;
   private static final int C_BLUE = 0xFF5AA2F0;
   private static final int C_YELLOW = 0xFFE8C14A;
   private static final int C_BTN = 0xFF2F3B4D;
   private static final int C_BTN_HOVER = 0xFF41516A;
   private static final int C_BTN_OFF = 0xFF202731;
   private static final int C_DARK = 0xFF0E1218;

   private static final int ROW_ORDER = 30;
   private static final int ROW_BUILDING = 48;
   private static final int MAX_LEVEL = 5;
   private static final int SB = 9; // largura da barra de rolagem (fácil de tocar)
   private static final int L_ORDERS = 0;
   private static final int L_BUILDERS = 1;
   private static final int L_BUILDINGS = 2;
   private static final int L_DASH = 3;
   private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
   private static final String[] ORDER_SORTS = {"ID", "Perto", "Tipo", "Livres"};
   private static final String[] BUILDING_SORTS = {"Nome", "Nível", "Estado"};

   private static final Map<String, String> NAMES = Map.ofEntries(
      Map.entry("builder", "Construtor"), Map.entry("townhall", "Prefeitura"), Map.entry("citizen", "Residência"),
      Map.entry("home", "Residência"), Map.entry("tavern", "Taverna"), Map.entry("miner", "Mineiro"),
      Map.entry("lumberjack", "Lenhador"), Map.entry("farmer", "Fazendeiro"), Map.entry("fisherman", "Pescador"),
      Map.entry("baker", "Padeiro"), Map.entry("blacksmith", "Ferreiro"), Map.entry("stonemason", "Pedreiro"),
      Map.entry("sawmill", "Serraria"), Map.entry("cook", "Cozinheiro"), Map.entry("restaurant", "Restaurante"),
      Map.entry("warehouse", "Armazém"), Map.entry("deliveryman", "Entregador"), Map.entry("library", "Biblioteca"),
      Map.entry("university", "Universidade"), Map.entry("hospital", "Hospital"), Map.entry("guardtower", "Torre de Guarda"),
      Map.entry("barracks", "Quartel"), Map.entry("barrackstower", "Torre do Quartel"), Map.entry("graveyard", "Cemitério"),
      Map.entry("school", "Escola"), Map.entry("shepherd", "Pastor"), Map.entry("cowboy", "Vaqueiro"),
      Map.entry("swineherder", "Porqueiro"), Map.entry("chickenherder", "Galinheiro"), Map.entry("composter", "Composteiro"),
      Map.entry("smeltery", "Fundição"), Map.entry("mechanic", "Mecânico"), Map.entry("alchemist", "Alquimista"),
      Map.entry("enchanter", "Encantador"), Map.entry("florist", "Floricultor"), Map.entry("plantation", "Plantação"),
      Map.entry("netherworker", "Minerador do Nether"), Map.entry("crusher", "Triturador"), Map.entry("sifter", "Peneirador"),
      Map.entry("concretemixer", "Betoneira"), Map.entry("dyer", "Tingidor"), Map.entry("fletcher", "Flecheiro"),
      Map.entry("glassblower", "Vidraceiro"), Map.entry("combatacademy", "Academia de Combate"), Map.entry("archery", "Arquearia"),
      Map.entry("mysticalsite", "Sítio Místico"), Map.entry("stash", "Esconderijo"), Map.entry("kitchen", "Cozinha"),
      Map.entry("beekeeper", "Apicultor"), Map.entry("rabbithutch", "Coelheira"), Map.entry("herbalist", "Herborista"),
      Map.entry("stone_smeltery", "Fundição de Pedra"), Map.entry("quarry", "Pedreira"), Map.entry("simple_quarry", "Pedreira Simples"),
      Map.entry("medium_quarry", "Pedreira Média"), Map.entry("large_quarry", "Pedreira Grande"), Map.entry("postbox", "Caixa de Correio")
   );

   // ---------- dados (persistem entre aberturas) ----------
   private static boolean loaded = false;
   private static String colonyName = "";
   private static List<NetworkHandler.OrderEntry> orders = new ArrayList<>();
   private static List<NetworkHandler.BuilderEntry> builders = new ArrayList<>();
   private static List<NetworkHandler.BuildingEntry> buildings = new ArrayList<>();
   private static int citizenCount = 0;
   private static int freeBuildersCount = 0;
   private static int pendingBuildsCount = 0;
   private static boolean autopilot = false;
   private static boolean autoQueue = false;
   private static boolean autoRefresh = true;
   private static int lastTab = 0;

   // ---------- registro de atividade ----------
   private static final class LogEntry {
      final String time;
      final int color;
      final String text;

      LogEntry(String time, int color, String text) {
         this.time = time;
         this.color = color;
         this.text = text;
      }
   }

   private static final List<LogEntry> LOG = new ArrayList<>();

   private static void log(int color, String text) {
      LOG.add(0, new LogEntry(LocalTime.now().format(TIME), color, text));
      while (LOG.size() > 40) {
         LOG.remove(LOG.size() - 1);
      }
   }

   private static void note(int[] budget, int color, String text) {
      if (budget[0] > 0) {
         log(color, text);
      }
      budget[0]--;
   }

   /** Compara o estado anterior com o novo e escreve o que mudou no registro de atividade. */
   private static void diff(NetworkHandler.ColonyDataPacket p) {
      int[] budget = {12};
      Map<Integer, NetworkHandler.OrderEntry> old = new HashMap<>();
      for (NetworkHandler.OrderEntry o : orders) {
         old.put(o.id, o);
      }
      for (NetworkHandler.OrderEntry n : p.orders) {
         NetworkHandler.OrderEntry o = old.remove(n.id);
         if (o == null) {
            note(budget, C_BLUE, "Nova ordem #" + n.id + ": " + typeLabel(n.type) + " " + n.name);
         } else if (o.available && !n.available) {
            note(budget, C_GREEN, "Ordem #" + n.id + " assumida por " + n.claimedBy);
         } else if (!o.available && n.available) {
            note(budget, C_YELLOW, "Ordem #" + n.id + " ficou livre");
         }
      }
      for (NetworkHandler.OrderEntry gone : old.values()) {
         note(budget, C_GREEN, "Ordem #" + gone.id + " encerrada (" + typeLabel(gone.type) + ")");
      }
      Map<Long, NetworkHandler.BuildingEntry> oldB = new HashMap<>();
      for (NetworkHandler.BuildingEntry b : buildings) {
         oldB.put(b.positionId, b);
      }
      for (NetworkHandler.BuildingEntry n : p.buildings) {
         NetworkHandler.BuildingEntry o = oldB.get(n.positionId);
         if (o == null) {
            note(budget, C_BLUE, "Novo prédio: " + prettyName(n.name));
         } else if (o.level != n.level) {
            note(budget, C_GOLD, prettyName(n.name) + " " + BlockPos.of(n.positionId).toShortString() + ": nível " + o.level + " -> " + n.level);
         }
      }
      if (budget[0] < 0) {
         log(C_DIM, "... e mais " + (-budget[0]) + " mudança(s)");
      }
   }

   // ---------- estado da tela ----------
   private final Set<Integer> selectedOrders = new LinkedHashSet<>();
   private final List<Long> selectedBuilders = new ArrayList<>();
   private final Set<Long> selectedBuildings = new LinkedHashSet<>();
   private int tab = 0; // 0 painel, 1 obras, 2 prédios
   private boolean onlyFreeOrders = false;
   private boolean onlyFreeBuilders = false;
   private int orderSort = 0;
   private int buildingSort = 0;
   private int buildingFilter = 0; // 0 todos, 1 construídos, 2 pendentes
   private String search = "";
   private final int[] scroll = new int[4];
   private final int[] contentH = new int[4];
   private final int[][] views = new int[4][4];
   private int[] clip = null;
   private long msgUntil = 0L;
   private int lastMx = 0;
   private int lastMy = 0;
   private int refreshTicks = 0;
   // arrastar para rolar (celular / mouse sem roda)
   private int dragList = -1;
   private boolean dragThumb = false;
   private boolean dragged = false;
   private double pressY = 0;
   private int pressScroll = 0;
   private Hit pendingHit = null;
   private boolean compact = false;
   private int rowH = ROW_ORDER;
   private String message = "Carregando colônia...";
   private int messageColor = C_DIM;
   private long armedRemove = Long.MIN_VALUE;
   private long armedUntil = 0L;
   private String armedBulk = "";
   private long armedBulkUntil = 0L;
   private EditBox searchBox;

   // ---------- layout ----------
   private int panelW;
   private int panelH;
   private int panelX;
   private int panelY;
   private final List<Hit> hits = new ArrayList<>();

   private static final class Hit {
      final int x;
      final int y;
      final int w;
      final int h;
      final boolean enabled;
      final String tip;
      final Runnable action;

      Hit(int x, int y, int w, int h, boolean enabled, String tip, Runnable action) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
         this.enabled = enabled;
         this.tip = tip;
         this.action = action;
      }

      boolean contains(double mx, double my) {
         return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
      }
   }

   private static final class Suggestion {
      final int color;
      final String text;
      final String tip;
      final Runnable action;

      Suggestion(int color, String text, String tip, Runnable action) {
         this.color = color;
         this.text = text;
         this.tip = tip;
         this.action = action;
      }
   }

   public RemoteColonyScreen() {
      super(Component.literal("Remote Colony Manager"));
      this.tab = lastTab;
   }

   // =====================================================================
   //  Entrada de dados vinda do servidor
   // =====================================================================
   public static void openOrUpdate(NetworkHandler.ColonyDataPacket p) {
      Minecraft mc = Minecraft.getInstance();
      boolean open = mc.screen instanceof RemoteColonyScreen;
      if (!open && !p.open) {
         return; // atualização silenciosa chegou depois de fechar o painel: ignora
      }
      if (loaded && open) {
         diff(p);
      }
      colonyName = p.colonyName;
      orders = new ArrayList<>(p.orders);
      builders = new ArrayList<>(p.builders);
      buildings = new ArrayList<>(p.buildings);
      citizenCount = p.citizenCount;
      freeBuildersCount = p.freeBuilders;
      pendingBuildsCount = p.pendingBuilds;
      autopilot = p.autopilot;
      autoQueue = p.autoQueue;
      loaded = true;
      if (!open) {
         RemoteColonyScreen s = new RemoteColonyScreen();
         mc.setScreen(s);
         s.onData(true);
      } else if (mc.screen instanceof RemoteColonyScreen s) {
         s.onData(false);
      }
   }

   public static void onFeedback(int kind, String text, boolean refresh) {
      int color = switch (kind) {
         case NetworkHandler.FB_OK -> C_GREEN;
         case NetworkHandler.FB_WARN -> C_YELLOW;
         case NetworkHandler.FB_ERROR -> C_RED;
         default -> C_BLUE;
      };
      log(color, text);
      Minecraft mc = Minecraft.getInstance();
      if (mc.screen instanceof RemoteColonyScreen s) {
         s.setMessage(text, color);
         if (refresh) {
            NetworkHandler.refresh(true);
         }
      } else if (mc.player != null) {
         mc.player.displayClientMessage(Component.literal("[RCM] " + text), true);
      }
   }

   private void onData(boolean fresh) {
      this.selectedOrders.removeIf(id -> orders.stream().noneMatch(v -> v.id == id));
      this.selectedBuilders.removeIf(pos -> builders.stream().noneMatch(v -> v.positionId == pos));
      this.selectedBuildings.removeIf(pos -> buildings.stream().noneMatch(v -> v.positionId == pos));
      if (fresh) {
         this.setMessage("Colônia carregada.", C_GREEN);
      }
   }

   // =====================================================================
   //  Inicialização / layout
   // =====================================================================
   protected void init() {
      this.calculateLayout();
      this.clearWidgets();
      this.searchBox = null;
      if (this.tab == 2) {
         int chips = 3 * (this.chipW() + 3);
         int w = Math.max(60, this.panelW - 16 - chips);
         this.searchBox = new EditBox(this.font, this.panelX + 8, this.contentTop(), w, 16, Component.literal("Buscar"));
         this.searchBox.setMaxLength(32);
         this.searchBox.setHint(Component.literal("Buscar prédio..."));
         this.searchBox.setValue(this.search);
         this.searchBox.setResponder(text -> {
            this.search = text == null ? "" : text;
            this.scroll[L_BUILDINGS] = 0;
         });
         this.addRenderableWidget(this.searchBox);
      }
   }

   private void calculateLayout() {
      this.panelW = Math.min(720, Math.max(200, this.width - 8));
      this.panelH = Math.min(440, Math.max(120, this.height - 6));
      this.panelX = (this.width - this.panelW) / 2;
      this.panelY = (this.height - this.panelH) / 2;
      this.compact = this.panelH < 300; // telas baixas (celular)
   }

   private int contentTop() {
      return this.panelY + (this.compact ? 45 : 68);
   }

   private int barY() {
      return this.panelY + this.panelH - (this.compact ? 20 : 50);
   }

   private int listBottomWithBar() {
      return this.panelY + this.panelH - (this.compact ? 24 : 54);
   }

   private int dashBottom() {
      return this.panelY + this.panelH - (this.compact ? 4 : 31);
   }

   private int chipW() {
      return this.compact ? 52 : 66;
   }

   private void setMessage(String text, int color) {
      this.message = text;
      this.messageColor = color;
      this.msgUntil = System.currentTimeMillis() + 4000L;
   }

   private void switchTab(int t) {
      if (this.tab != t) {
         this.tab = t;
         lastTab = t;
         this.rebuildWidgets();
      }
   }

   public void tick() {
      super.tick();
      if (autoRefresh && ++this.refreshTicks >= 100) {
         this.refreshTicks = 0;
         NetworkHandler.refresh(true);
      }
   }

   // =====================================================================
   //  Helpers de desenho
   // =====================================================================
   private void border(GuiGraphics g, int x, int y, int w, int h, int color) {
      g.fill(x, y, x + w, y + 1, color);
      g.fill(x, y + h - 1, x + w, y + h, color);
      g.fill(x, y, x + 1, y + h, color);
      g.fill(x + w - 1, y, x + w, y + h, color);
   }

   private String fit(String text, int maxWidth) {
      if (text == null) {
         return "";
      }
      if (this.font.width(text) <= maxWidth) {
         return text;
      }
      return this.font.plainSubstrByWidth(text, Math.max(0, maxWidth - this.font.width("..."))) + "...";
   }

   private List<String> wrap(String text, int maxW) {
      List<String> lines = new ArrayList<>();
      StringBuilder cur = new StringBuilder();
      for (String word : text.split(" ")) {
         String test = cur.length() == 0 ? word : cur + " " + word;
         if (this.font.width(test) > maxW && cur.length() > 0) {
            lines.add(cur.toString());
            cur = new StringBuilder(word);
         } else {
            cur = new StringBuilder(test);
         }
      }
      if (cur.length() > 0) {
         lines.add(cur.toString());
      }
      return lines;
   }

   /** Hover respeitando a área visível da lista (clip). */
   private boolean hoverAt(int mx, int my, int x, int y, int w, int h) {
      if (mx < x || mx >= x + w || my < y || my >= y + h) {
         return false;
      }
      return this.clip == null || (mx >= this.clip[0] && mx < this.clip[2] && my >= this.clip[1] && my < this.clip[3]);
   }

   /** Registra uma área clicável, já recortada pela área visível da lista. */
   private void addHit(int x, int y, int w, int h, boolean enabled, String tip, Runnable action) {
      int x1 = x;
      int y1 = y;
      int x2 = x + w;
      int y2 = y + h;
      if (this.clip != null) {
         x1 = Math.max(x1, this.clip[0]);
         y1 = Math.max(y1, this.clip[1]);
         x2 = Math.min(x2, this.clip[2]);
         y2 = Math.min(y2, this.clip[3]);
         if (x2 <= x1 || y2 <= y1) {
            return;
         }
      }
      this.hits.add(new Hit(x1, y1, x2 - x1, y2 - y1, enabled, tip, action));
   }

   private void button(GuiGraphics g, int mx, int my, int x, int y, int w, int h, String label, boolean enabled, int accent, String tip, Runnable action) {
      boolean hover = enabled && this.hoverAt(mx, my, x, y, w, h);
      g.fill(x, y, x + w, y + h, !enabled ? C_BTN_OFF : (hover ? C_BTN_HOVER : C_BTN));
      g.fill(x, y + h - 1, x + w, y + h, enabled ? accent : 0xFF2A313B);
      g.drawCenteredString(this.font, this.fit(label, w - 4), x + w / 2, y + (h - 8) / 2, enabled ? C_TEXT : 0xFF5C6673);
      this.addHit(x, y, w, h, enabled, tip, action);
   }

   private void chip(GuiGraphics g, int mx, int my, int x, int y, int w, String label, boolean on, String tip, Runnable action) {
      boolean hover = this.hoverAt(mx, my, x, y, w, 14);
      g.fill(x, y, x + w, y + 14, on ? 0xFF2E5A8C : (hover ? C_BTN_HOVER : C_BTN));
      this.border(g, x, y, w, 14, on ? C_BLUE : C_BORDER);
      g.drawCenteredString(this.font, this.fit(label, w - 2), x + w / 2, y + 3, on ? 0xFFFFFFFF : C_DIM);
      this.addHit(x, y, w, 14, true, tip, action);
   }

   private void checkbox(GuiGraphics g, int x, int y, boolean checked, boolean enabled) {
      g.fill(x, y, x + 10, y + 10, enabled ? C_DARK : 0xFF181D25);
      this.border(g, x, y, 10, 10, checked ? C_BLUE : (enabled ? C_BORDER : 0xFF2A313B));
      if (checked) {
         g.fill(x + 2, y + 2, x + 8, y + 8, C_BLUE);
      }
   }

   private int statusChip(GuiGraphics g, int x, int y, int color, String label) {
      g.fill(x, y + 2, x + 5, y + 7, color);
      g.drawString(this.font, label, x + 8, y, color);
      return x + 8 + this.font.width(label);
   }

   private static int clamp(int v, int lo, int hi) {
      return Math.max(lo, Math.min(hi, v));
   }

   private static boolean inside(int[] v, double mx, double my) {
      return mx >= v[0] && mx < v[2] && my >= v[1] && my < v[3];
   }

   // ---------- rolagem ----------
   private boolean listActive(int i) {
      return switch (this.tab) {
         case 0 -> i == L_DASH;
         case 1 -> i == L_ORDERS || i == L_BUILDERS;
         default -> i == L_BUILDINGS;
      };
   }

   private int maxScroll(int i) {
      int[] v = this.views[i];
      return Math.max(0, this.contentH[i] - (v[3] - v[1]));
   }

   private int stepOf(int i) {
      return i == L_BUILDINGS ? ROW_BUILDING : (i == L_DASH ? 20 : this.rowH);
   }

   private int listAt(double mx, double my) {
      for (int i = 0; i < 4; i++) {
         if (this.listActive(i) && inside(this.views[i], mx, my)) {
            return i;
         }
      }
      return -1;
   }

   private int thumbH(int i) {
      int[] v = this.views[i];
      int viewH = v[3] - v[1];
      int trackH = Math.max(1, viewH - 2 * SB);
      return Math.max(12, Math.min(trackH, trackH * viewH / Math.max(1, this.contentH[i])));
   }

   private int thumbY(int i) {
      int[] v = this.views[i];
      int trackH = Math.max(1, (v[3] - v[1]) - 2 * SB);
      int th = this.thumbH(i);
      int ms = this.maxScroll(i);
      return v[1] + SB + (ms == 0 ? 0 : (int) ((long) Math.max(0, trackH - th) * this.scroll[i] / ms));
   }

   /** Barra de rolagem larga: seta para cima, trilho com alça arrastável, seta para baixo. */
   private void scrollbar(GuiGraphics g, int i) {
      int[] v = this.views[i];
      int viewH = v[3] - v[1];
      if (this.contentH[i] <= viewH) {
         return;
      }
      int bx = v[2] - SB;
      g.fill(bx, v[1], bx + SB, v[3], C_DARK);
      g.fill(bx, v[1], bx + SB, v[1] + SB - 1, C_BTN);
      g.fill(bx, v[3] - SB + 1, bx + SB, v[3], C_BTN);
      g.drawCenteredString(this.font, "^", bx + SB / 2 + 1, v[1] + 1, C_TEXT);
      g.drawCenteredString(this.font, "v", bx + SB / 2 + 1, v[3] - SB + 1, C_TEXT);
      int ty = this.thumbY(i);
      g.fill(bx + 1, ty, bx + SB - 1, ty + this.thumbH(i), C_GOLD);
   }

   private void beginList(GuiGraphics g, int i, int x1, int y1, int x2, int y2) {
      this.views[i] = new int[]{x1, y1, x2, y2};
      this.scroll[i] = clamp(this.scroll[i], 0, this.maxScroll(i));
      this.clip = this.views[i];
      g.enableScissor(x1, y1, x2, y2);
   }

   private void endList(GuiGraphics g, int i) {
      g.disableScissor();
      this.clip = null;
      this.scrollbar(g, i);
   }

   // ---------- dados derivados ----------
   private static int countFreeOrders() {
      int n = 0;
      for (NetworkHandler.OrderEntry o : orders) {
         if (o.available) n++;
      }
      return n;
   }

   private static int countActiveBuilders() {
      int n = 0;
      for (NetworkHandler.BuilderEntry b : builders) {
         if (b.hasWorker) n++;
      }
      return n;
   }

   private static int countBuilt() {
      int n = 0;
      for (NetworkHandler.BuildingEntry b : buildings) {
         if (b.isBuilt()) n++;
      }
      return n;
   }

   private static int distanceTo(long posLong) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null) {
         return -1;
      }
      BlockPos p = BlockPos.of(posLong);
      double dx = p.getX() + 0.5 - mc.player.getX();
      double dy = p.getY() - mc.player.getY();
      double dz = p.getZ() + 0.5 - mc.player.getZ();
      return (int) Math.sqrt(dx * dx + dy * dy + dz * dz);
   }

   private static String fmtDist(int d) {
      if (d < 0) return "?";
      return d >= 1000 ? String.format(Locale.ROOT, "%.1fkm", d / 1000.0) : d + "m";
   }

   private String statusLine() {
      return "Cidadãos " + citizenCount + "  |  Ordens " + countFreeOrders() + "/" + orders.size() + " livres"
         + "  |  Construtores " + freeBuildersCount + "/" + countActiveBuilders() + " livres  |  Pendentes " + pendingBuildsCount;
   }

   private List<Suggestion> suggestions() {
      List<Suggestion> list = new ArrayList<>();
      int freeOrders = countFreeOrders();
      int noWorker = 0;
      for (NetworkHandler.BuilderEntry b : builders) {
         if (!b.hasWorker) noWorker++;
      }
      if (builders.isEmpty() && (pendingBuildsCount > 0 || !orders.isEmpty())) {
         list.add(new Suggestion(C_RED, "Nenhuma cabana de construtor encontrada na colônia.", null, null));
      }
      if (freeOrders > 0 && freeBuildersCount > 0) {
         int n = Math.min(freeOrders, freeBuildersCount);
         list.add(new Suggestion(C_GREEN, "Distribuir " + n + " ordem(ns) agora (toque aqui)", "Atribui ordens livres aos melhores construtores", this::assignAllFree));
      } else if (freeOrders > 0) {
         list.add(new Suggestion(C_YELLOW, freeOrders + " ordem(ns) livre(s), mas nenhum construtor livre.", "Abrir aba Obras", () -> this.switchTab(1)));
      }
      if (noWorker > 0) {
         list.add(new Suggestion(C_RED, noWorker + " cabana(s) de construtor sem trabalhador.", "Contrate construtores na colônia", null));
      }
      if (pendingBuildsCount > 0) {
         list.add(new Suggestion(C_BLUE, pendingBuildsCount + " prédio(s) aguardando construção (ver)", "Abrir aba Prédios filtrando pendentes", () -> {
            this.buildingFilter = 2;
            this.scroll[L_BUILDINGS] = 0;
            this.switchTab(2);
         }));
      }
      if (!autoQueue && (this.countGenerate("BUILD") > 0 || this.countGenerate("UPGRADE") > 0)) {
         list.add(new Suggestion(C_GOLD, "Dica: ligue a Fila automática para criar construções e melhorias sozinha.", "Liga a fila automática", this::toggleAutoQueue));
      }
      if (!autopilot && freeOrders > 0) {
         list.add(new Suggestion(C_GOLD, "Dica: ligue o Piloto automático para distribuir sozinho.", "Liga o piloto automático", this::toggleAutopilot));
      }
      if (list.isEmpty()) {
         list.add(new Suggestion(C_GREEN, "Tudo em dia. Nenhuma ação necessária.", null, null));
      }
      return list;
   }

   // =====================================================================
   //  Render
   // =====================================================================
   public void render(GuiGraphics g, int mx, int my, float pt) {
      this.calculateLayout();
      this.lastMx = mx;
      this.lastMy = my;
      this.hits.clear();
      this.clip = null;
      this.renderBackground(g);
      int x = this.panelX;
      int y = this.panelY;
      int w = this.panelW;
      int h = this.panelH;

      g.fill(x - 1, y - 1, x + w + 1, y + h + 1, C_BORDER);
      g.fill(x, y, x + w, y + h, C_BG);
      this.renderHeader(g, mx, my, x, y, w);
      this.renderTabs(g, mx, my, x, y, w);
      if (this.tab == 0) {
         this.renderDashboard(g, mx, my, x, w);
      } else if (this.tab == 1) {
         this.renderWorksTab(g, mx, my, x, y, w, h);
      } else {
         this.renderBuildingsTab(g, mx, my, x, y, w, h);
      }
      this.renderFooter(g, mx, my, x, y, w, h);
      super.render(g, mx, my, pt);

      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit hit = this.hits.get(i);
         if (hit.tip != null && hit.contains(mx, my)) {
            g.renderTooltip(this.font, Component.literal(hit.tip), mx, my);
            break;
         }
      }
   }

   private void renderHeader(GuiGraphics g, int mx, int my, int x, int y, int w) {
      int hh = this.compact ? 25 : 37;
      g.fillGradient(x, y, x + w, y + hh - 1, C_HEAD_TOP, C_HEAD_BOT);
      g.fill(x, y + hh - 1, x + w, y + hh, C_GOLD);
      int freeOrders = countFreeOrders();
      String title = "REMOTE COLONY MANAGER  v" + VERSION;
      int barTop;
      if (this.compact) {
         g.drawString(this.font, this.fit(title, w - 118), x + 6, y + 5, C_GOLD);
         this.button(g, mx, my, x + w - 104, y + 3, 54, 13, "Atualizar", true, C_BLUE, "Recarrega os dados da colônia", this::manualRefresh);
         this.button(g, mx, my, x + w - 46, y + 3, 40, 13, "Fechar", true, C_RED, null, this::onClose);
         boolean showMsg = System.currentTimeMillis() < this.msgUntil;
         g.drawString(this.font, this.fit(showMsg ? this.message : this.statusLine(), w - 12), x + 6, y + 14, showMsg ? this.messageColor : C_DIM);
         barTop = y + 21;
      } else {
         g.drawString(this.font, title, x + 9, y + 7, C_GOLD);
         if (!colonyName.isEmpty()) {
            String name = this.fit(colonyName, w / 2 - 20);
            g.drawString(this.font, name, x + w - 9 - this.font.width(name), y + 7, C_TEXT);
         }
         int sx = this.statusChip(g, x + 9, y + 21, autoRefresh ? C_GREEN : C_DIM, autoRefresh ? "AO VIVO" : "PAUSADO");
         sx = this.statusChip(g, sx + 8, y + 21, autopilot ? C_GOLD : C_DIM, autopilot ? "PILOTO ON" : "PILOTO OFF");
         sx = this.statusChip(g, sx + 8, y + 21, autoQueue ? C_GOLD : C_DIM, autoQueue ? "FILA ON" : "FILA OFF");
         int rest = x + w - 9 - (sx + 12);
         if (rest > 80) {
            g.drawString(this.font, this.fit(this.statusLine(), rest), sx + 12, y + 21, C_DIM);
         }
         barTop = y + 33;
      }
      int total = orders.size();
      g.fill(x, barTop, x + w, barTop + 3, C_DARK);
      if (total > 0) {
         g.fill(x, barTop, x + (int) ((long) w * (total - freeOrders) / total), barTop + 3, C_GREEN);
      }
   }

   private void renderTabs(GuiGraphics g, int mx, int my, int x, int y, int w) {
      int gap = 4;
      int tw = (w - 16 - gap * 2) / 3;
      int ty = y + (this.compact ? 28 : 42);
      int th = this.compact ? 14 : 20;
      int free = countFreeOrders();
      this.tabButton(g, mx, my, x + 8, ty, tw, th, "Painel", 0);
      this.tabButton(g, mx, my, x + 8 + tw + gap, ty, tw, th, free > 0 ? "Obras (" + free + ")" : "Obras", 1);
      this.tabButton(g, mx, my, x + 8 + 2 * (tw + gap), ty, tw, th, "Prédios", 2);
   }

   private void tabButton(GuiGraphics g, int mx, int my, int bx, int by, int bw, int bh, String label, int index) {
      boolean active = this.tab == index;
      boolean hover = this.hoverAt(mx, my, bx, by, bw, bh);
      g.fill(bx, by, bx + bw, by + bh, active ? 0xFF2E5A8C : (hover ? C_BTN_HOVER : C_BTN));
      g.fill(bx, by + bh - 2, bx + bw, by + bh, active ? C_GOLD : 0xFF2A313B);
      g.drawCenteredString(this.font, this.fit(label, bw - 6), bx + bw / 2, by + (bh - 8) / 2 - 1, active ? 0xFFFFFFFF : C_DIM);
      this.addHit(bx, by, bw, bh, true, null, () -> this.switchTab(index));
   }

   // ---------------------------------------------------------------------
   //  Aba 0: Painel
   // ---------------------------------------------------------------------
   private void section(GuiGraphics g, int x, int y, int w, String title) {
      g.drawString(this.font, title, x + 1, y + 1, C_GOLD);
      g.fill(x + this.font.width(title) + 6, y + 5, x + w, y + 6, 0xFF2A313B);
   }

   private void renderDashboard(GuiGraphics g, int mx, int my, int x, int w) {
      int top = this.contentTop();
      int left = x + 8;
      int right = x + w - 8;
      int aw = right - left - SB - 2;
      this.beginList(g, L_DASH, left, top, right, this.dashBottom());
      int startY = top - this.scroll[L_DASH];
      int cy = startY;

      // ---- cartões de estatística ----
      int freeOrders = countFreeOrders();
      int active = countActiveBuilders();
      String[] vals = {String.valueOf(citizenCount), freeBuildersCount + "/" + active, freeOrders + "/" + orders.size(), countBuilt() + "/" + buildings.size()};
      String[] labs = {"Cidadãos", "Construtores livres", "Ordens livres", "Prédios (" + pendingBuildsCount + " pend.)"};
      String[] tips = {"Moradores da colônia", "Abrir aba Obras", "Abrir aba Obras", "Abrir aba Prédios"};
      int[] acc = {C_BLUE, C_GREEN, C_GOLD, C_YELLOW};
      int[] goTab = {-1, 1, 1, 2};
      int cols = aw >= 330 ? 4 : 2;
      int gap = 4;
      int cardW = (aw - gap * (cols - 1)) / cols;
      int cardH = this.compact ? 30 : 44;
      for (int i = 0; i < 4; i++) {
         int cx = left + (i % cols) * (cardW + gap);
         int cyy = cy + (i / cols) * (cardH + gap);
         boolean hover = goTab[i] >= 0 && this.hoverAt(mx, my, cx, cyy, cardW, cardH);
         g.fill(cx, cyy, cx + cardW, cyy + cardH, hover ? C_CARD_HOVER : C_CARD);
         g.fill(cx, cyy, cx + cardW, cyy + 2, acc[i]);
         if (this.compact) {
            g.drawString(this.font, this.fit(vals[i], cardW - 8), cx + 6, cyy + 6, C_TEXT);
            g.drawString(this.font, this.fit(labs[i], cardW - 8), cx + 6, cyy + 18, C_DIM);
         } else {
            float s = this.font.width(vals[i]) * 2 <= cardW - 10 ? 2.0F : 1.0F;
            g.pose().pushPose();
            g.pose().scale(s, s, 1.0F);
            g.drawString(this.font, vals[i], (int) ((cx + 7) / s), (int) ((cyy + 8) / s), C_TEXT);
            g.pose().popPose();
            g.drawString(this.font, this.fit(labs[i], cardW - 10), cx + 7, cyy + cardH - 12, C_DIM);
         }
         if (goTab[i] >= 0) {
            final int target = goTab[i];
            this.addHit(cx, cyy, cardW, cardH, true, tips[i], () -> this.switchTab(target));
         }
      }
      cy += ((4 + cols - 1) / cols) * (cardH + gap) + 2;

      // ---- progresso ----
      this.section(g, left, cy, aw, "PROGRESSO DAS OBRAS");
      cy += 13;
      int total = orders.size();
      g.fill(left, cy, left + aw, cy + 11, C_DARK);
      if (total > 0) {
         g.fill(left, cy, left + (int) ((long) aw * (total - freeOrders) / total), cy + 11, 0xFF2F7A45);
      }
      this.border(g, left, cy, aw, 11, C_BORDER);
      String prog = total == 0 ? "Nenhuma ordem de obra no momento" : (total - freeOrders) + " de " + total + " ordens em andamento";
      g.drawCenteredString(this.font, this.fit(prog, aw - 4), left + aw / 2, cy + 2, C_TEXT);
      cy += 16;

      // ---- controles ----
      this.section(g, left, cy, aw, "CONTROLES");
      cy += 13;
      int bw = (aw - 4) / 2;
      this.button(g, mx, my, left, cy, bw, 16, "Piloto: " + (autopilot ? "LIGADO" : "DESLIGADO"), true, autopilot ? C_GREEN : C_RED,
         "Atribui ordens livres sozinho (a cada 5 s)", this::toggleAutopilot);
      this.button(g, mx, my, left + bw + 4, cy, bw, 16, "Auto-atualizar: " + (autoRefresh ? "SIM" : "NÃO"), true, autoRefresh ? C_GREEN : C_RED,
         "Atualiza o painel a cada 5 s", () -> {
            autoRefresh = !autoRefresh;
            this.refreshTicks = 0;
            this.setMessage(autoRefresh ? "Atualização automática ligada." : "Atualização automática desligada.", C_BLUE);
         });
      cy += 19;
      this.button(g, mx, my, left, cy, bw, 16, "Fila auto: " + (autoQueue ? "LIGADA" : "DESLIGADA"), true, autoQueue ? C_GREEN : C_RED,
         "Cria construções e melhorias sozinha (builder livre)", this::toggleAutoQueue);
      this.button(g, mx, my, left + bw + 4, cy, bw, 16, this.generateLabel("BUILD"), this.countGenerate("BUILD") > 0, C_BLUE,
         "Cria ordens para todos os prédios pendentes", () -> this.generateOrders("BUILD"));
      cy += 19;
      this.button(g, mx, my, left, cy, bw, 16, this.generateLabel("UPGRADE"), this.countGenerate("UPGRADE") > 0, C_GREEN,
         "Cria ordens de melhoria para todos os prédios", () -> this.generateOrders("UPGRADE"));
      cy += 20;
      for (String line : this.wrap("Piloto automático: atribui as ordens livres ao melhor construtor (maior nível, depois o mais próximo), mesmo com o painel fechado. Fila automática: quando há construtor livre e nenhuma ordem esperando, cria sozinha a próxima construção ou melhoria (até o nível 5). Shift + botão direito com o item liga/desliga o piloto.", aw - 2)) {
         g.drawString(this.font, line, left + 1, cy, C_DIM);
         cy += 10;
      }
      cy += 4;

      // ---- sugestões ----
      this.section(g, left, cy, aw, "SUGESTÕES");
      cy += 13;
      for (Suggestion s : this.suggestions()) {
         boolean hover = s.action != null && this.hoverAt(mx, my, left, cy, aw, 15);
         g.fill(left, cy, left + aw, cy + 15, hover ? C_CARD_HOVER : C_CARD);
         g.fill(left, cy, left + 3, cy + 15, s.color);
         g.drawString(this.font, this.fit(s.text, aw - 12), left + 8, cy + 4, s.color == C_GREEN || s.color == C_BLUE || s.color == C_GOLD ? C_TEXT : s.color);
         if (s.action != null) {
            this.addHit(left, cy, aw, 15, true, s.tip, s.action);
         }
         cy += 17;
      }
      cy += 3;

      // ---- atividade ----
      this.section(g, left, cy, aw, "ATIVIDADE RECENTE");
      cy += 13;
      if (LOG.isEmpty()) {
         g.drawString(this.font, this.fit("Nada ainda. As mudanças da colônia aparecem aqui.", aw), left + 1, cy, C_DIM);
         cy += 12;
      }
      int tw = this.font.width("00:00:00") + 6;
      for (int i = 0; i < Math.min(12, LOG.size()); i++) {
         LogEntry e = LOG.get(i);
         g.drawString(this.font, e.time, left + 1, cy, 0xFF5C6673);
         g.drawString(this.font, this.fit(e.text, aw - tw - 2), left + tw, cy, e.color);
         cy += 11;
      }
      cy += 4;

      this.contentH[L_DASH] = cy - startY;
      this.endList(g, L_DASH);
   }

   // ---------------------------------------------------------------------
   //  Aba 1: Obras (ordens x construtores)
   // ---------------------------------------------------------------------
   private List<NetworkHandler.OrderEntry> visibleOrders() {
      List<NetworkHandler.OrderEntry> list = new ArrayList<>();
      for (NetworkHandler.OrderEntry o : orders) {
         if (!this.onlyFreeOrders || o.available) {
            list.add(o);
         }
      }
      switch (this.orderSort) {
         case 1 -> list.sort(Comparator.comparingInt((NetworkHandler.OrderEntry o) -> distanceTo(o.pos)));
         case 2 -> list.sort(Comparator.comparingInt((NetworkHandler.OrderEntry o) -> o.type).thenComparingInt(o -> o.id));
         case 3 -> list.sort(Comparator.comparing((NetworkHandler.OrderEntry o) -> !o.available).thenComparingInt(o -> o.id));
         default -> { }
      }
      return list;
   }

   private List<NetworkHandler.BuilderEntry> visibleBuilders() {
      List<NetworkHandler.BuilderEntry> list = new ArrayList<>();
      for (NetworkHandler.BuilderEntry b : builders) {
         if (!this.onlyFreeBuilders || (b.hasWorker && b.free)) {
            list.add(b);
         }
      }
      return list;
   }

   private void renderWorksTab(GuiGraphics g, int mx, int my, int x, int y, int w, int h) {
      int colW = (w - 24) / 2;
      int leftX = x + 8;
      int rightX = x + 16 + colW;
      int headY = this.contentTop();
      int listTop = headY + (this.compact ? 17 : 18);
      int listBottom = this.listBottomWithBar() - (this.compact ? 0 : 22);
      int avail = listBottom - listTop;
      this.rowH = avail >= 5 * ROW_ORDER ? ROW_ORDER : Math.max(18, Math.min(ROW_ORDER, avail / 5));
      int rowW = colW - SB - 2;
      int cw = this.compact ? 38 : 62;
      boolean wide = colW >= 190;

      // ---- cabeçalhos ----
      String oTitle = this.compact ? "ORDENS " + this.selectedOrders.size() : "ORDENS (" + this.selectedOrders.size() + " sel.)";
      String bTitle = this.compact ? "CONSTR. " + this.selectedBuilders.size() : "CONSTRUTORES (" + this.selectedBuilders.size() + " sel.)";
      g.drawString(this.font, oTitle, leftX + 1, headY + 3, C_GOLD);
      int cxp = leftX + colW;
      cxp -= cw;
      this.chip(g, mx, my, cxp, headY, cw, this.compact ? "Livres" : "Só livres", this.onlyFreeOrders, "Mostrar apenas ordens sem construtor", () -> {
         this.onlyFreeOrders = !this.onlyFreeOrders;
         this.scroll[L_ORDERS] = 0;
      });
      cxp -= cw + 2;
      this.chip(g, mx, my, cxp, headY, cw, this.compact ? ORDER_SORTS[this.orderSort] : "Ord: " + ORDER_SORTS[this.orderSort], false, "Ordenar: ID, mais perto, tipo, livres primeiro", () -> {
         this.orderSort = (this.orderSort + 1) % ORDER_SORTS.length;
         this.scroll[L_ORDERS] = 0;
      });
      if (wide) {
         cxp -= cw + 2;
         this.chip(g, mx, my, cxp, headY, cw, this.compact ? "Todas" : "Sel. livres", false, "Seleciona todas as ordens livres", () -> {
            for (NetworkHandler.OrderEntry o : orders) {
               if (o.available) {
                  this.selectedOrders.add(o.id);
               }
            }
            this.setMessage(this.selectedOrders.size() + " ordem(ns) selecionada(s).", C_BLUE);
         });
      }
      g.drawString(this.font, bTitle, rightX + 1, headY + 3, C_GOLD);
      this.chip(g, mx, my, rightX + colW - cw, headY, cw, this.compact ? "Livres" : "Só livres", this.onlyFreeBuilders, "Mostrar apenas construtores disponíveis", () -> {
         this.onlyFreeBuilders = !this.onlyFreeBuilders;
         this.scroll[L_BUILDERS] = 0;
      });

      // ---- ordens ----
      List<NetworkHandler.OrderEntry> vo = this.visibleOrders();
      this.contentH[L_ORDERS] = vo.size() * this.rowH;
      this.beginList(g, L_ORDERS, leftX, listTop, leftX + colW, listBottom);
      if (vo.isEmpty()) {
         g.drawString(this.font, orders.isEmpty() ? "Nenhuma ordem de construção." : "Nenhuma ordem livre.", leftX + 4, listTop + 6, C_DIM);
      }
      for (int i = 0; i < vo.size(); i++) {
         int ry = listTop + i * this.rowH - this.scroll[L_ORDERS];
         if (ry + this.rowH < listTop || ry > listBottom) {
            continue;
         }
         this.renderOrderRow(g, mx, my, vo.get(i), leftX, ry, rowW);
      }
      this.endList(g, L_ORDERS);

      // ---- construtores ----
      List<NetworkHandler.BuilderEntry> vb = this.visibleBuilders();
      this.contentH[L_BUILDERS] = vb.size() * this.rowH;
      this.beginList(g, L_BUILDERS, rightX, listTop, rightX + colW, listBottom);
      if (vb.isEmpty()) {
         g.drawString(this.font, builders.isEmpty() ? "Nenhuma cabana de construtor." : "Nenhum construtor livre.", rightX + 4, listTop + 6, C_DIM);
      }
      for (int i = 0; i < vb.size(); i++) {
         int ry = listTop + i * this.rowH - this.scroll[L_BUILDERS];
         if (ry + this.rowH < listTop || ry > listBottom) {
            continue;
         }
         this.renderBuilderRow(g, mx, my, vb.get(i), rightX, ry, rowW);
      }
      this.endList(g, L_BUILDERS);

      // ---- gerar ordens (linha extra, só em tela maior; no celular use o Painel) ----
      if (!this.compact) {
         int gy = this.barY() - 22;
         int gw = (w - 16 - 6) / 3;
         this.button(g, mx, my, x + 8, gy, gw, 18, this.generateLabel("BUILD"), this.countGenerate("BUILD") > 0, C_BLUE,
            "Cria ordens para todos os prédios pendentes", () -> this.generateOrders("BUILD"));
         this.button(g, mx, my, x + 8 + gw + 3, gy, gw, 18, this.generateLabel("UPGRADE"), this.countGenerate("UPGRADE") > 0, C_GREEN,
            "Cria ordens de melhoria para todos os prédios", () -> this.generateOrders("UPGRADE"));
         this.button(g, mx, my, x + 8 + (gw + 3) * 2, gy, gw, 18, "Fila auto: " + (autoQueue ? "LIGADA" : "DESLIGADA"), true, autoQueue ? C_GREEN : C_RED,
            "Cria construções e melhorias sozinha", this::toggleAutoQueue);
      }

      // ---- ações ----
      int ah = this.compact ? 16 : 18;
      int ay = this.barY();
      int gap = 3;
      int bw = (w - 16 - gap * 4) / 5;
      boolean pairOk = !this.selectedOrders.isEmpty() && this.selectedOrders.size() == this.selectedBuilders.size();
      boolean claimedSel = this.selectedOrders.stream().anyMatch(id -> orders.stream().anyMatch(o -> o.id == id && !o.available));
      this.button(g, mx, my, x + 8, ay, bw, ah, "Atribuir", pairOk, C_BLUE, "Liga a 1ª ordem ao 1º construtor, 2ª ao 2º... (mesma qtd.)", this::manualAssign);
      this.button(g, mx, my, x + 8 + (bw + gap), ay, bw, ah, "Auto", !this.selectedOrders.isEmpty(), C_GREEN, "Melhor construtor: maior nível, depois o mais próximo", this::automaticAssign);
      this.button(g, mx, my, x + 8 + (bw + gap) * 2, ay, bw, ah, this.compact ? "Livres" : "Todas livres", countFreeOrders() > 0, C_GOLD, "Distribui automaticamente todas as ordens livres", this::assignAllFree);
      this.button(g, mx, my, x + 8 + (bw + gap) * 3, ay, bw, ah, "Liberar", claimedSel, C_YELLOW, "Libera (unclaim) as ordens selecionadas já atribuídas", this::cancelSelectedOrders);
      this.button(g, mx, my, x + 8 + (bw + gap) * 4, ay, bw, ah, "Limpar", !this.selectedOrders.isEmpty() || !this.selectedBuilders.isEmpty(), C_RED, "Limpa a seleção de ordens e construtores", () -> {
         this.selectedOrders.clear();
         this.selectedBuilders.clear();
         this.setMessage("Seleção limpa.", C_DIM);
      });
   }

   private void renderOrderRow(GuiGraphics g, int mx, int my, NetworkHandler.OrderEntry o, int rx, int ry, int rw) {
      boolean sel = this.selectedOrders.contains(o.id);
      int rh = this.rowH;
      boolean thin = rh < 28;
      boolean hover = this.hoverAt(mx, my, rx, ry, rw, rh - 2);
      g.fill(rx, ry, rx + rw, ry + rh - 2, sel ? C_CARD_SEL : (hover ? C_CARD_HOVER : C_CARD));
      int accent = typeColor(o.type);
      g.fill(rx, ry, rx + 3, ry + rh - 2, o.available ? accent : 0xFF3A4252);
      this.checkbox(g, rx + 8, ry + (rh - 2 - 10) / 2, sel, true);
      int tx = rx + 24;
      int tw = rw - 28;
      String head = "#" + o.id + "  " + typeLabel(o.type) + "  ·  " + (o.name.isEmpty() ? "?" : o.name);
      String status = o.available ? "Livre" : o.claimedBy;
      int stColor = o.available ? C_GREEN : C_YELLOW;
      String loc = BlockPos.of(o.pos).toShortString() + "  (" + fmtDist(distanceTo(o.pos)) + ")";
      if (thin) {
         int ty = ry + (rh - 2 - 8) / 2;
         int sw = Math.min(this.font.width(status), tw / 2);
         g.drawString(this.font, this.fit(head, tw - sw - 8), tx, ty, o.available ? accent : C_DIM);
         g.drawString(this.font, this.fit(status, sw), rx + rw - sw - 4, ty, stColor);
      } else {
         int sw = Math.min(this.font.width(status), tw / 2);
         g.drawString(this.font, this.fit(head, tw), tx, ry + 4, o.available ? accent : C_DIM);
         g.drawString(this.font, this.fit(loc, tw - sw - 8), tx, ry + 15, C_DIM);
         g.drawString(this.font, this.fit(status, sw), rx + rw - sw - 4, ry + 15, stColor);
      }
      String tip = o.available ? (o.name.isEmpty() ? "Ordem livre" : o.name) : "Com " + o.claimedBy + " (selecione e use Liberar)";
      this.addHit(rx, ry, rw, rh - 2, true, tip, () -> {
         if (!this.selectedOrders.add(o.id)) {
            this.selectedOrders.remove(o.id);
         }
         this.setMessage(this.selectedOrders.size() + " ordem(ns) selecionada(s).", C_BLUE);
      });
   }

   private void renderBuilderRow(GuiGraphics g, int mx, int my, NetworkHandler.BuilderEntry b, int rx, int ry, int rw) {
      boolean selectable = b.hasWorker && b.free;
      int idx = this.selectedBuilders.indexOf(b.positionId);
      boolean sel = idx >= 0;
      int rh = this.rowH;
      boolean thin = rh < 28;
      boolean hover = selectable && this.hoverAt(mx, my, rx, ry, rw, rh - 2);
      g.fill(rx, ry, rx + rw, ry + rh - 2, sel ? C_CARD_SEL : (hover ? C_CARD_HOVER : C_CARD));
      int statusColor = !b.hasWorker ? C_RED : (b.free ? C_GREEN : C_YELLOW);
      g.fill(rx, ry, rx + 3, ry + rh - 2, statusColor);
      this.checkbox(g, rx + 8, ry + (rh - 2 - 10) / 2, sel, selectable);
      int tx = rx + 24;
      int tw = rw - 28;
      String lvl = "Nv." + b.level;
      int lw = this.font.width(lvl);
      String who = b.hasWorker ? b.citizens : "Sem trabalhador";
      String status = !b.hasWorker ? "Vago" : (b.free ? "Livre" : (b.orderId >= 0 ? "Obra #" + b.orderId : "Ocupado"));
      int sw = this.font.width(status);
      if (thin) {
         int ty = ry + (rh - 2 - 8) / 2;
         g.drawString(this.font, this.fit(who, tw - lw - sw - 16), tx, ty, selectable ? C_TEXT : C_DIM);
         g.drawString(this.font, lvl, rx + rw - sw - lw - 10, ty, C_GOLD);
         g.drawString(this.font, status, rx + rw - sw - 4, ty, statusColor);
      } else {
         String loc = BlockPos.of(b.positionId).toShortString() + "  (" + fmtDist(distanceTo(b.positionId)) + ")";
         g.drawString(this.font, this.fit(who, tw - lw - 8), tx, ry + 4, selectable ? C_TEXT : C_DIM);
         g.drawString(this.font, lvl, rx + rw - lw - 4, ry + 4, C_GOLD);
         g.drawString(this.font, this.fit(loc, tw - sw - 8), tx, ry + 15, C_DIM);
         g.drawString(this.font, status, rx + rw - sw - 4, ry + 15, statusColor);
      }
      String tip = selectable ? (sel ? "Selecionado (par " + (idx + 1) + ")" : who) : (b.hasWorker ? "Este construtor já tem uma ordem" : "Contrate um construtor nesta cabana");
      this.addHit(rx, ry, rw, rh - 2, selectable, tip, () -> {
         if (!this.selectedBuilders.remove(b.positionId)) {
            this.selectedBuilders.add(b.positionId);
         }
         this.setMessage(this.selectedBuilders.size() + " construtor(es) selecionado(s).", C_BLUE);
      });
   }

   // ---------------------------------------------------------------------
   //  Aba 2: Prédios
   // ---------------------------------------------------------------------
   private List<NetworkHandler.BuildingEntry> visibleBuildings() {
      List<NetworkHandler.BuildingEntry> list = new ArrayList<>();
      String q = this.search.trim().toLowerCase(Locale.ROOT);
      for (NetworkHandler.BuildingEntry b : buildings) {
         if (this.buildingFilter == 1 && !b.isBuilt()) {
            continue;
         }
         if (this.buildingFilter == 2 && b.isBuilt()) {
            continue;
         }
         if (!q.isEmpty() && !b.name.toLowerCase(Locale.ROOT).contains(q) && !prettyName(b.name).toLowerCase(Locale.ROOT).contains(q)) {
            continue;
         }
         list.add(b);
      }
      switch (this.buildingSort) {
         case 1 -> list.sort(Comparator.comparingInt((NetworkHandler.BuildingEntry b) -> b.level));
         case 2 -> list.sort(Comparator.comparingInt((NetworkHandler.BuildingEntry b) -> b.hasOrder() ? 0 : (b.isBuilt() ? 2 : 1)));
         default -> { }
      }
      return list;
   }

   private int countEligible(String action) {
      int n = 0;
      for (NetworkHandler.BuildingEntry b : buildings) {
         if (this.selectedBuildings.contains(b.positionId) && eligible(b, action)) {
            n++;
         }
      }
      return n;
   }

   private static boolean eligible(NetworkHandler.BuildingEntry b, String action) {
      if (b.hasOrder()) {
         return false;
      }
      return switch (action) {
         case "BUILD" -> !b.isBuilt();
         case "UPGRADE", "REPAIR", "REMOVE" -> b.isBuilt();
         default -> false;
      };
   }

   private void renderBuildingsTab(GuiGraphics g, int mx, int my, int x, int y, int w, int h) {
      int chipW = this.chipW();
      int cx = x + w - 8 - 3 * (chipW + 3) + 3;
      int row1 = this.contentTop();
      int chipY = row1 + 1;
      this.chip(g, mx, my, cx, chipY, chipW, "Todos", this.buildingFilter == 0, "Mostrar todos os prédios", () -> {
         this.buildingFilter = 0;
         this.scroll[L_BUILDINGS] = 0;
      });
      this.chip(g, mx, my, cx + chipW + 3, chipY, chipW, this.compact ? "Prontos" : "Construídos", this.buildingFilter == 1, "Apenas prédios já construídos", () -> {
         this.buildingFilter = 1;
         this.scroll[L_BUILDINGS] = 0;
      });
      this.chip(g, mx, my, cx + 2 * (chipW + 3), chipY, chipW, this.compact ? "Pend." : "Pendentes", this.buildingFilter == 2, "Apenas prédios aguardando construção", () -> {
         this.buildingFilter = 2;
         this.scroll[L_BUILDINGS] = 0;
      });

      List<NetworkHandler.BuildingEntry> vis = this.visibleBuildings();
      int row2 = row1 + (this.compact ? 17 : 18);
      int selW = this.compact ? 52 : 66;
      int sortW = this.compact ? 62 : 78;
      int selX = x + w - 8 - selW;
      int sortX = selX - 3 - sortW;
      boolean allSel = !vis.isEmpty() && vis.stream().allMatch(b -> this.selectedBuildings.contains(b.positionId));
      this.chip(g, mx, my, selX, row2, selW, this.compact ? "Todos" : "Sel. todos", allSel, "Seleciona/desmarca todos os prédios visíveis", () -> {
         for (NetworkHandler.BuildingEntry b : vis) {
            if (allSel) {
               this.selectedBuildings.remove(b.positionId);
            } else {
               this.selectedBuildings.add(b.positionId);
            }
         }
      });
      this.chip(g, mx, my, sortX, row2, sortW, "Ord: " + BUILDING_SORTS[this.buildingSort], false, "Ordenar por nome, nível ou estado", () -> {
         this.buildingSort = (this.buildingSort + 1) % BUILDING_SORTS.length;
         this.scroll[L_BUILDINGS] = 0;
      });
      g.drawString(this.font, this.fit(vis.size() + " de " + buildings.size() + " prédios  |  " + this.selectedBuildings.size() + " sel.", sortX - x - 14), x + 9, row2 + 3, C_DIM);

      int listTop = row2 + 17;
      int listBottom = this.listBottomWithBar();
      int lx = x + 8;
      int lw = w - 16;
      this.contentH[L_BUILDINGS] = vis.size() * ROW_BUILDING;
      this.beginList(g, L_BUILDINGS, lx, listTop, lx + lw, listBottom);
      if (vis.isEmpty()) {
         g.drawString(this.font, buildings.isEmpty() ? "Nenhum prédio registrado encontrado." : "Nenhum prédio corresponde ao filtro.", lx + 4, listTop + 6, C_DIM);
      }
      for (int i = 0; i < vis.size(); i++) {
         int ry = listTop + i * ROW_BUILDING - this.scroll[L_BUILDINGS];
         if (ry + ROW_BUILDING < listTop || ry > listBottom) {
            continue;
         }
         this.renderBuildingRow(g, mx, my, vis.get(i), lx, ry, lw - SB - 2);
      }
      this.endList(g, L_BUILDINGS);

      // ---- ações em lote ----
      int ah = this.compact ? 16 : 18;
      int ay = this.barY();
      int gap = 3;
      int bw = (w - 16 - gap * 3) / 4;
      int nb = this.countEligible("BUILD");
      int nu = this.countEligible("UPGRADE");
      int nr = this.countEligible("REPAIR");
      String fmt = this.compact ? "%s %d" : "%s (%d)";
      this.button(g, mx, my, x + 8, ay, bw, ah, String.format(fmt, this.compact ? "Constr." : "Construir", nb), nb > 0, C_BLUE, "Cria ordens de construção dos selecionados pendentes", () -> this.bulkAction("BUILD"));
      this.button(g, mx, my, x + 8 + (bw + gap), ay, bw, ah, String.format(fmt, "Evoluir", nu), nu > 0, C_GREEN, "Pede melhoria dos selecionados construídos", () -> this.bulkAction("UPGRADE"));
      this.button(g, mx, my, x + 8 + (bw + gap) * 2, ay, bw, ah, String.format(fmt, "Reparar", nr), nr > 0, C_YELLOW, "Pede reparo dos selecionados construídos", () -> this.bulkAction("REPAIR"));
      this.button(g, mx, my, x + 8 + (bw + gap) * 3, ay, bw, ah, "Limpar", !this.selectedBuildings.isEmpty(), C_RED, "Desmarca todos os prédios", () -> {
         this.selectedBuildings.clear();
         this.setMessage("Seleção limpa.", C_DIM);
      });
   }

   private void renderBuildingRow(GuiGraphics g, int mx, int my, NetworkHandler.BuildingEntry b, int rx, int ry, int rw) {
      boolean sel = this.selectedBuildings.contains(b.positionId);
      boolean hover = this.hoverAt(mx, my, rx, ry, rw, ROW_BUILDING - 2);
      g.fill(rx, ry, rx + rw, ry + ROW_BUILDING - 2, sel ? C_CARD_SEL : (hover ? C_CARD_HOVER : C_CARD));
      boolean built = b.isBuilt();
      boolean hasOrder = b.hasOrder();
      int stateColor = hasOrder ? C_YELLOW : (built ? C_GREEN : C_BLUE);
      g.fill(rx, ry, rx + 3, ry + ROW_BUILDING - 2, stateColor);
      // toque no cartão marca/desmarca; os botões abaixo são registrados depois e têm prioridade
      this.addHit(rx, ry, rw, ROW_BUILDING - 2, true, null, () -> {
         if (!this.selectedBuildings.add(b.positionId)) {
            this.selectedBuildings.remove(b.positionId);
         }
      });
      this.checkbox(g, rx + 8, ry + 4, sel, true);

      // linha 1: nome + pips de nível
      int nx = rx + 22;
      g.drawString(this.font, this.fit(prettyName(b.name), rw / 2 - 14), nx, ry + 4, C_TEXT);
      int pipX = rx + rw - 8 - MAX_LEVEL * 8;
      for (int i = 0; i < MAX_LEVEL; i++) {
         g.fill(pipX + i * 8, ry + 5, pipX + i * 8 + 6, ry + 11, i < b.level ? C_GOLD : C_DARK);
         this.border(g, pipX + i * 8, ry + 5, 6, 6, i < b.level ? 0xFFB98A2E : 0xFF303846);
      }
      String lvl = "Nv." + b.level;
      g.drawString(this.font, lvl, pipX - this.font.width(lvl) - 5, ry + 4, C_GOLD);

      // linha 2: posição + distância + estado
      String status = hasOrder ? "Já possui uma ordem" : (built ? "Prédio construído" : "Aguardando construção");
      int sw = this.font.width(status);
      String pos = BlockPos.of(b.positionId).toShortString() + "  (" + fmtDist(distanceTo(b.positionId)) + ")";
      g.drawString(this.font, this.fit(pos, rw - sw - 24), rx + 9, ry + 16, C_DIM);
      g.drawString(this.font, status, rx + rw - sw - 6, ry + 16, stateColor);

      // linha 3: ações
      String[] labels = {"Construir", "Evoluir", "Reparar", "Remover"};
      String[] actions = {"BUILD", "UPGRADE", "REPAIR", "REMOVE"};
      String[] tips = {"Cria uma ordem de construção", "Pede a melhoria para o próximo nível", "Pede o reparo do prédio", "Pede a remoção (pede confirmação)"};
      int[] accents = {C_BLUE, C_GREEN, C_YELLOW, C_RED};
      int gap = 3;
      int bw = (rw - 18 - gap * 3) / 4;
      for (int a = 0; a < 4; a++) {
         String action = actions[a];
         int bx = rx + 9 + a * (bw + gap);
         int by = ry + 29;
         boolean on = eligible(b, action);
         boolean armed = a == 3 && this.armedRemove == b.positionId && System.currentTimeMillis() < this.armedUntil;
         boolean bHover = on && this.hoverAt(mx, my, bx, by, bw, 14);
         g.fill(bx, by, bx + bw, by + 14, !on ? C_BTN_OFF : (armed ? 0xFF7A2B2B : (bHover ? C_BTN_HOVER : C_BTN)));
         g.fill(bx, by + 13, bx + bw, by + 14, on ? accents[a] : 0xFF2A313B);
         g.drawCenteredString(this.font, this.fit(armed ? "Confirmar?" : labels[a], bw - 2), bx + bw / 2, by + 3, on ? C_TEXT : 0xFF5C6673);
         this.addHit(bx, by, bw, 14, on, tips[a], () -> this.act(b, action));
      }
   }

   // =====================================================================
   //  Rodapé
   // =====================================================================
   private void renderFooter(GuiGraphics g, int mx, int my, int x, int y, int w, int h) {
      if (this.compact) {
         return; // em tela pequena, Atualizar/Fechar/mensagens ficam no cabeçalho
      }
      int fy = y + h - 26;
      g.fill(x, fy - 3, x + w, fy - 2, 0xFF2A313B);
      this.button(g, mx, my, x + 8, fy, 80, 18, "Atualizar", true, C_BLUE, "Recarrega os dados da colônia", this::manualRefresh);
      this.button(g, mx, my, x + w - 88, fy, 80, 18, "Fechar", true, C_RED, "Fechar (ou aperte K)", this::onClose);
      String msg = this.fit(this.message, w - 190);
      g.drawCenteredString(this.font, msg, x + w / 2, fy + 5, this.messageColor);
   }

   // =====================================================================
   //  Entrada
   // =====================================================================
   public boolean mouseClicked(double mx, double my, int button) {
      if (super.mouseClicked(mx, my, button)) {
         return true;
      }
      if (button != 0) {
         return false;
      }
      int li = this.listAt(mx, my);
      if (li >= 0) {
         int[] v = this.views[li];
         int viewH = v[3] - v[1];
         if (this.contentH[li] > viewH && mx >= v[2] - SB) {
            // barra de rolagem: seta cima / seta baixo / alça / trilho
            int step = this.stepOf(li);
            int ms = this.maxScroll(li);
            if (my < v[1] + SB) {
               this.scroll[li] = clamp(this.scroll[li] - step, 0, ms);
            } else if (my >= v[3] - SB) {
               this.scroll[li] = clamp(this.scroll[li] + step, 0, ms);
            } else {
               int ty = this.thumbY(li);
               if (my >= ty && my < ty + this.thumbH(li)) {
                  this.dragList = li;
                  this.dragThumb = true;
                  this.dragged = true;
                  this.pressY = my;
                  this.pressScroll = this.scroll[li];
               } else {
                  this.scroll[li] = clamp(this.scroll[li] + (my < ty ? -viewH : viewH), 0, ms);
               }
            }
            return true;
         }
         // toque/clique no conteúdo: só vira clique se soltar sem arrastar (arrastar = rolar)
         this.dragList = li;
         this.dragThumb = false;
         this.dragged = false;
         this.pressY = my;
         this.pressScroll = this.scroll[li];
         this.pendingHit = null;
         for (int i = this.hits.size() - 1; i >= 0; i--) {
            Hit hit = this.hits.get(i);
            if (hit.contains(mx, my)) {
               this.pendingHit = hit;
               break;
            }
         }
         return true;
      }
      for (int i = this.hits.size() - 1; i >= 0; i--) {
         Hit hit = this.hits.get(i);
         if (hit.contains(mx, my)) {
            if (hit.enabled && hit.action != null) {
               hit.action.run();
            }
            return true;
         }
      }
      return false;
   }

   public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
      if (this.dragList >= 0 && button == 0) {
         int i = this.dragList;
         int ms = this.maxScroll(i);
         if (this.dragThumb) {
            int[] v = this.views[i];
            int trackH = Math.max(1, (v[3] - v[1]) - 2 * SB);
            int range = Math.max(1, trackH - this.thumbH(i));
            this.scroll[i] = clamp(this.pressScroll + (int) ((my - this.pressY) * ms / range), 0, ms);
         } else {
            if (!this.dragged && Math.abs(my - this.pressY) > 4) {
               this.dragged = true;
            }
            if (this.dragged) {
               this.scroll[i] = clamp(this.pressScroll + (int) (this.pressY - my), 0, ms);
            }
         }
         return true;
      }
      return super.mouseDragged(mx, my, button, dx, dy);
   }

   public boolean mouseReleased(double mx, double my, int button) {
      if (this.dragList >= 0 && button == 0) {
         Hit hit = this.pendingHit;
         boolean wasClick = !this.dragged && !this.dragThumb;
         this.dragList = -1;
         this.dragThumb = false;
         this.dragged = false;
         this.pendingHit = null;
         if (wasClick && hit != null && hit.enabled && hit.action != null && hit.contains(mx, my)) {
            hit.action.run();
         }
         return true;
      }
      return super.mouseReleased(mx, my, button);
   }

   public boolean mouseScrolled(double mx, double my, double delta) {
      int i = this.listAt(mx, my);
      if (i >= 0) {
         this.scroll[i] = clamp(this.scroll[i] + (int) (-delta * 20), 0, this.maxScroll(i));
         return true;
      }
      return super.mouseScrolled(mx, my, delta);
   }

   public boolean keyPressed(int key, int scan, int mods) {
      if (this.searchBox != null && this.searchBox.isFocused()) {
         return super.keyPressed(key, scan, mods);
      }
      if (ClientEvents.OPEN_KEY.matches(key, scan)) {
         this.onClose();
         return true;
      }
      int i = this.listAt(this.lastMx, this.lastMy);
      if (i < 0) {
         i = this.tab == 0 ? L_DASH : (this.tab == 1 ? L_ORDERS : L_BUILDINGS);
      }
      int[] v = this.views[i];
      int page = Math.max(this.stepOf(i), v[3] - v[1] - this.stepOf(i));
      int ms = this.maxScroll(i);
      int cur = this.scroll[i];
      if (key == GLFW.GLFW_KEY_UP) {
         this.scroll[i] = clamp(cur - this.stepOf(i), 0, ms);
         return true;
      } else if (key == GLFW.GLFW_KEY_DOWN) {
         this.scroll[i] = clamp(cur + this.stepOf(i), 0, ms);
         return true;
      } else if (key == GLFW.GLFW_KEY_PAGE_UP) {
         this.scroll[i] = clamp(cur - page, 0, ms);
         return true;
      } else if (key == GLFW.GLFW_KEY_PAGE_DOWN) {
         this.scroll[i] = clamp(cur + page, 0, ms);
         return true;
      } else if (key == GLFW.GLFW_KEY_HOME) {
         this.scroll[i] = 0;
         return true;
      } else if (key == GLFW.GLFW_KEY_END) {
         this.scroll[i] = ms;
         return true;
      }
      return super.keyPressed(key, scan, mods);
   }

   // =====================================================================
   //  Ações
   // =====================================================================
   private void manualRefresh() {
      this.setMessage("Atualizando...", C_DIM);
      this.refreshTicks = 0;
      NetworkHandler.refresh(false);
   }

   private void toggleAutopilot() {
      autopilot = !autopilot;
      NetworkHandler.requestAutopilot(autopilot);
      this.setMessage(autopilot ? "Ligando piloto automático..." : "Desligando piloto automático...", C_GOLD);
   }

   private void toggleAutoQueue() {
      autoQueue = !autoQueue;
      NetworkHandler.requestAutoQueue(autoQueue);
      this.setMessage(autoQueue ? "Ligando fila automática..." : "Desligando fila automática...", C_GOLD);
   }

   private int countGenerate(String action) {
      int n = 0;
      for (NetworkHandler.BuildingEntry b : buildings) {
         if (eligible(b, action) && (!"UPGRADE".equals(action) || b.level < MAX_LEVEL)) {
            n++;
         }
      }
      return n;
   }

   private String generateLabel(String action) {
      boolean armed = action.equals(this.armedBulk) && System.currentTimeMillis() < this.armedBulkUntil;
      if (armed) {
         return "Confirmar?";
      }
      return ("BUILD".equals(action) ? "Construir pendentes" : "Evoluir todos") + " (" + this.countGenerate(action) + ")";
   }

   /** Cria ordens para todos os prédios elegíveis (pede um segundo toque para confirmar). */
   private void generateOrders(String action) {
      List<Long> targets = new ArrayList<>();
      for (NetworkHandler.BuildingEntry b : buildings) {
         if (eligible(b, action) && (!"UPGRADE".equals(action) || b.level < MAX_LEVEL)) {
            targets.add(b.positionId);
         }
      }
      if (targets.isEmpty()) {
         this.setMessage("Nada para gerar agora.", C_DIM);
         return;
      }
      long now = System.currentTimeMillis();
      if (!action.equals(this.armedBulk) || now > this.armedBulkUntil) {
         this.armedBulk = action;
         this.armedBulkUntil = now + 4000L;
         this.setMessage("Toque de novo para confirmar: " + targets.size() + " ordem(ns) de " + actionLabel(action) + ".", C_YELLOW);
         return;
      }
      this.armedBulk = "";
      for (int i = 0; i < targets.size(); i += 400) {
         NetworkHandler.requestBuildingAction(new ArrayList<>(targets.subList(i, Math.min(targets.size(), i + 400))), action);
      }
      this.setMessage("Gerando " + targets.size() + " ordem(ns) de " + actionLabel(action) + "...", C_BLUE);
   }

   private void act(NetworkHandler.BuildingEntry building, String action) {
      if ("REMOVE".equals(action)) {
         long now = System.currentTimeMillis();
         if (this.armedRemove != building.positionId || now > this.armedUntil) {
            this.armedRemove = building.positionId;
            this.armedUntil = now + 4000L;
            this.setMessage("Clique em \"Confirmar?\" para remover " + prettyName(building.name) + ".", C_YELLOW);
            return;
         }
         this.armedRemove = Long.MIN_VALUE;
      }
      List<Long> one = new ArrayList<>();
      one.add(building.positionId);
      NetworkHandler.requestBuildingAction(one, action);
      this.setMessage("Pedido enviado: " + actionLabel(action) + " - " + prettyName(building.name), C_BLUE);
   }

   private void bulkAction(String action) {
      List<Long> targets = new ArrayList<>();
      for (NetworkHandler.BuildingEntry b : buildings) {
         if (this.selectedBuildings.contains(b.positionId) && eligible(b, action)) {
            targets.add(b.positionId);
         }
      }
      if (targets.isEmpty()) {
         this.setMessage("Nenhum prédio selecionado serve para essa ação.", C_RED);
         return;
      }
      NetworkHandler.requestBuildingAction(targets, action);
      this.selectedBuildings.removeAll(targets);
      this.setMessage("Pedido enviado: " + actionLabel(action) + " x" + targets.size(), C_BLUE);
   }

   private void manualAssign() {
      if (!this.selectedOrders.isEmpty() && !this.selectedBuilders.isEmpty()) {
         if (this.selectedOrders.size() != this.selectedBuilders.size()) {
            this.setMessage("Selecione a mesma quantidade dos dois lados.", C_RED);
         } else {
            NetworkHandler.assignManual(new ArrayList<>(this.selectedOrders), new ArrayList<>(this.selectedBuilders));
            this.selectedOrders.clear();
            this.selectedBuilders.clear();
            this.setMessage("Enviando atribuições...", C_BLUE);
         }
      } else {
         this.setMessage("Selecione ordens e construtores.", C_RED);
      }
   }

   private void automaticAssign() {
      if (this.selectedOrders.isEmpty()) {
         this.setMessage("Selecione as ordens para distribuir automaticamente.", C_RED);
      } else {
         NetworkHandler.autoDistribute(new ArrayList<>(this.selectedOrders));
         this.selectedOrders.clear();
         this.setMessage("Distribuindo (melhor nível, depois mais próximo)...", C_BLUE);
      }
   }

   private void assignAllFree() {
      List<Integer> freeIds = new ArrayList<>();
      for (NetworkHandler.OrderEntry o : orders) {
         if (o.available) {
            freeIds.add(o.id);
         }
      }
      if (freeIds.isEmpty()) {
         this.setMessage("Nenhuma ordem livre disponível.", C_RED);
         return;
      }
      NetworkHandler.autoDistribute(freeIds);
      this.selectedOrders.clear();
      this.setMessage("Atribuindo as " + freeIds.size() + " ordens livres...", C_BLUE);
   }

   private void cancelSelectedOrders() {
      if (this.selectedOrders.isEmpty()) {
         this.setMessage("Selecione ordens para liberar.", C_RED);
         return;
      }
      NetworkHandler.cancelOrders(new ArrayList<>(this.selectedOrders));
      this.selectedOrders.clear();
      this.setMessage("Liberando ordens selecionadas...", C_YELLOW);
   }

   // =====================================================================
   //  Utilidades
   // =====================================================================
   private static String actionLabel(String action) {
      return switch (action) {
         case "BUILD" -> "Construir";
         case "UPGRADE" -> "Evoluir";
         case "REPAIR" -> "Reparar";
         case "REMOVE" -> "Remover";
         default -> action;
      };
   }

   private static String typeLabel(int type) {
      return WorkOrderTypeNames.label(type);
   }

   private static int typeColor(int type) {
      return switch (type) {
         case 0 -> C_BLUE;
         case 1 -> C_GREEN;
         case 2 -> C_YELLOW;
         case 3 -> C_RED;
         default -> C_DIM;
      };
   }

   private static String prettyName(String raw) {
      if (raw == null || raw.isEmpty()) {
         return "Prédio";
      }
      String key = raw.toLowerCase(Locale.ROOT).replace(" ", "").replace("_", "");
      String translated = NAMES.get(key);
      if (translated != null) {
         return translated;
      }
      StringBuilder sb = new StringBuilder();
      for (String part : raw.replace('_', ' ').split(" ")) {
         if (part.isEmpty()) {
            continue;
         }
         if (sb.length() > 0) {
            sb.append(' ');
         }
         sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
      }
      return sb.toString();
   }

   public boolean isPauseScreen() {
      return false;
   }
}

