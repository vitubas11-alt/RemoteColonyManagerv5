package com.vitor.remotecolonymanager;

import com.minecolonies.api.colony.ICitizenData;
import com.minecolonies.api.colony.IColony;
import com.minecolonies.api.colony.IColonyManager;
import com.minecolonies.api.colony.buildings.IBuilding;
import com.minecolonies.api.colony.workorders.IBuilderWorkOrder;
import com.minecolonies.api.colony.workorders.IServerWorkOrder;
import com.minecolonies.api.colony.workorders.WorkOrderType;
import com.minecolonies.core.colony.buildings.AbstractSchematicProvider;
import com.minecolonies.core.colony.buildings.workerbuildings.BuildingBuilder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.minecraftforge.network.simple.SimpleChannel;

public class NetworkHandler {
   private static final String PROTOCOL = "6";
   /** Limite de itens por pacote vindo do cliente (proteção contra pacotes malformados). */
   private static final int MAX_LIST = 512;
   /** Nível máximo até onde a Fila automática evolui prédios. */
   private static final int AUTO_MAX_LEVEL = 5;
   private static final Map<Long, Long> QUEUE_FAIL_UNTIL = new HashMap<>();
   public static final int FB_INFO = 0;
   public static final int FB_OK = 1;
   public static final int FB_WARN = 2;
   public static final int FB_ERROR = 3;

   private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
      new ResourceLocation(RemoteColonyManager.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals
   );
   private static final Map<UUID, Long> LAST_AUTO_REFRESH = new HashMap<>();
   private static boolean registered = false;

   public static void register() {
      if (registered) {
         return;
      }
      registered = true;
      CHANNEL.registerMessage(0, ColonyDataPacket.class, ColonyDataPacket::encode, ColonyDataPacket::decode, ColonyDataPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
      CHANNEL.registerMessage(1, AssignPacket.class, AssignPacket::encode, AssignPacket::decode, AssignPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
      CHANNEL.registerMessage(2, RefreshPacket.class, RefreshPacket::encode, RefreshPacket::decode, RefreshPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
      CHANNEL.registerMessage(3, BuildingActionPacket.class, BuildingActionPacket::encode, BuildingActionPacket::decode, BuildingActionPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
      CHANNEL.registerMessage(4, CancelOrdersPacket.class, CancelOrdersPacket::encode, CancelOrdersPacket::decode, CancelOrdersPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
      CHANNEL.registerMessage(5, AutopilotPacket.class, AutopilotPacket::encode, AutopilotPacket::decode, AutopilotPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
      CHANNEL.registerMessage(6, FeedbackPacket.class, FeedbackPacket::encode, FeedbackPacket::decode, FeedbackPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
   }

   // =====================================================================
   //  Servidor: utilidades
   // =====================================================================

   public static void openScreen(ServerPlayer player) {
      IColony colony = getPlayerColony(player);
      if (colony == null) {
         player.sendSystemMessage(Component.literal("Não encontrei uma colônia sua neste mundo."));
      } else {
         sendData(player, colony, true, true);
      }
   }

   /** Mensagem de resultado mostrada dentro do painel (ou na barra de ação se o painel estiver fechado). */
   public static void feedback(ServerPlayer player, int kind, String text, boolean refresh) {
      CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new FeedbackPacket(kind, text, refresh));
   }

   public static void setAutopilot(ServerPlayer player, boolean enable) {
      IColony colony = getPlayerColony(player);
      if (colony == null) {
         feedback(player, FB_WARN, "Não encontrei uma colônia sua neste mundo.", false);
         return;
      }
      Autopilot.setEnabled(player, enable);
      int n = 0;
      if (enable) {
         try {
            n = autopilotStep(player);
         } catch (Exception ex) {
            RemoteColonyManager.LOGGER.error("[RCM] Falha no piloto automático", ex);
         }
      }
      String text = enable ? "Piloto automático LIGADO" + (n > 0 ? " (" + n + " ordem(ns) atribuída(s))" : "") : "Piloto automático DESLIGADO";
      feedback(player, FB_OK, text, false);
      sendData(player, colony, false, false);
   }

   public static void setAutoQueue(ServerPlayer player, boolean enable) {
      IColony colony = getPlayerColony(player);
      if (colony == null) {
         feedback(player, FB_WARN, "Não encontrei uma colônia sua neste mundo.", false);
         return;
      }
      Autopilot.setQueueEnabled(player, enable);
      feedback(player, FB_OK, enable ? "Fila automática LIGADA: cria construções e melhorias quando há construtor livre." : "Fila automática DESLIGADA", false);
      sendData(player, colony, false, false);
   }

   /**
    * Fila automática: quando há mais construtores livres do que ordens livres, cria sozinha
    * a(s) próxima(s) ordem(ns): primeiro construções pendentes, depois melhorias (do menor nível para o maior).
    * Prédios que falham ficam 2 minutos em espera para não repetir o erro.
    * Retorna quantas ordens foram criadas.
    */
   public static int autoQueueStep(ServerPlayer player) {
      IColony colony = getPlayerColony(player);
      if (colony == null) {
         return 0;
      }
      List<BuildingBuilder> builders = getBuilders(colony);
      if (builders.isEmpty()) {
         return 0;
      }
      int freeBuilders = 0;
      for (BuildingBuilder b : builders) {
         if (hasWorker(b) && !b.hasWorkOrder()) freeBuilders++;
      }
      int freeOrders = 0;
      for (IServerWorkOrder raw : colony.getWorkManager().getWorkOrders().values()) {
         if (raw instanceof IBuilderWorkOrder o && !o.isClaimed()) freeOrders++;
      }
      int need = Math.min(2, freeBuilders - freeOrders);
      if (need <= 0) {
         return 0;
      }
      long now = System.currentTimeMillis();
      List<IBuilding> pending = new ArrayList<>();
      List<IBuilding> upgrades = new ArrayList<>();
      for (IBuilding building : colony.getServerBuildingManager().getBuildings().values()) {
         BlockPos pos = building.getPosition();
         Long until = QUEUE_FAIL_UNTIL.get(pos.asLong());
         if ((until != null && until > now) || hasOrderAt(colony, pos)) {
            continue;
         }
         int level = getUpdatedBuildingLevel(building);
         if (!(building.isBuilt() || level > 0)) {
            pending.add(building);
         } else if (level < AUTO_MAX_LEVEL) {
            upgrades.add(building);
         }
      }
      upgrades.sort(Comparator.comparingInt(b -> b.getBuildingLevel()));
      List<IBuilding> queue = new ArrayList<>(pending);
      queue.addAll(upgrades);
      int created = 0;
      for (IBuilding building : queue) {
         if (created >= need) {
            break;
         }
         BlockPos pos = building.getPosition();
         boolean built = building.isBuilt() || building.getBuildingLevel() > 0;
         String err = performBuildingAction(player, colony, pos, built ? "UPGRADE" : "BUILD", builders);
         if (err == null) {
            created++;
         } else {
            QUEUE_FAIL_UNTIL.put(pos.asLong(), now + 120000L);
         }
      }
      return created;
   }

   /** Atribui todas as ordens livres ao melhor construtor livre. Retorna quantas foram atribuídas. */
   public static int autopilotStep(ServerPlayer player) {
      IColony colony = getPlayerColony(player);
      if (colony == null) {
         return 0;
      }
      List<BuildingBuilder> builders = getBuilders(colony);
      if (builders.isEmpty()) {
         return 0;
      }
      List<IBuilderWorkOrder> free = new ArrayList<>();
      for (IServerWorkOrder raw : colony.getWorkManager().getWorkOrders().values()) {
         if (raw instanceof IBuilderWorkOrder order && !order.isClaimed()) {
            free.add(order);
         }
      }
      free.sort(Comparator.comparingInt(o -> o.getID()));
      int assigned = 0;
      for (IBuilderWorkOrder order : free) {
         BuildingBuilder best = chooseBestBuilder(order, builders);
         if (best != null && assignOne(colony, order, best)) {
            assigned++;
         }
      }
      return assigned;
   }

   private static IColony getPlayerColony(ServerPlayer player) {
      return IColonyManager.getInstance().getIColonyByOwner(player.serverLevel(), player);
   }

   private static List<BuildingBuilder> getBuilders(IColony colony) {
      List<BuildingBuilder> result = new ArrayList<>();

      for (IBuilding building : colony.getServerBuildingManager().getBuildings().values()) {
         if (building instanceof BuildingBuilder builder) {
            result.add(builder);
         }
      }

      result.sort(Comparator.comparingLong(b -> b.getPosition().asLong()));
      return result;
   }

   private static boolean hasWorker(BuildingBuilder builder) {
      return builder != null && builder.getAllAssignedCitizen() != null && !builder.getAllAssignedCitizen().isEmpty();
   }

   private static boolean hasOrderAt(IColony colony, BlockPos pos) {
      for (IServerWorkOrder order : colony.getWorkManager().getWorkOrders().values()) {
         if (pos.equals(order.getLocation())) {
            return true;
         }
      }

      return false;
   }

   /** Escolhe uma cabana de construtor capaz de atender ao nível solicitado.
    * A ordem é criada pelo próprio MineColonies e depois liberada para seleção manual/automática no RCM.
    */
   private static BuildingBuilder findOrderCreator(IBuilding target, WorkOrderType type, List<BuildingBuilder> builders) {
      int targetLevel = target.getBuildingLevel();
      if (type == WorkOrderType.BUILD) targetLevel = 1;
      else if (type == WorkOrderType.UPGRADE) targetLevel++;
      else if (type == WorkOrderType.REMOVE) targetLevel = 0;
      final int requiredLevel = targetLevel;
      final boolean targetAllowsLowerLevelBuilder = target.canBeBuiltByBuilder(requiredLevel);
      return builders.stream()
         .filter(b -> b.getBuildingLevel() >= requiredLevel || targetAllowsLowerLevelBuilder)
         .min(Comparator
            .comparing((BuildingBuilder b) -> !(hasWorker(b) && !b.hasWorkOrder()))
            .thenComparing(Comparator.comparingInt(BuildingBuilder::getBuildingLevel).reversed())
            .thenComparingDouble(b -> b.getPosition().distSqr(target.getPosition())))
         .orElse(null);
   }

   /** Remove a reserva temporária usada pelo MineColonies para validar a solicitação remota. */
   private static boolean releaseOrderAt(IColony colony, BlockPos pos) {
      for (IServerWorkOrder raw : colony.getWorkManager().getWorkOrders().values()) {
         if (pos.equals(raw.getLocation()) && raw instanceof IBuilderWorkOrder order) {
            order.setClaimedBy(null);
            colony.getWorkManager().setDirty(true);
            colony.markDirty();
            return true;
         }
      }

      return false;
   }

   /** Prédios colocados, mas ainda sem ordem, entram automaticamente na lista oficial do MineColonies. */
   private static void ensurePendingBuildOrders(ServerPlayer player, IColony colony) {
      List<BuildingBuilder> builders = getBuilders(colony);
      if (builders.isEmpty()) return;
      for (IBuilding building : colony.getServerBuildingManager().getBuildings().values()) {
         BlockPos pos = building.getPosition();
         if (hasOrderAt(colony, pos) || building.isBuilt() || getUpdatedBuildingLevel(building) > 0) continue;
         BuildingBuilder creator = findOrderCreator(building, WorkOrderType.BUILD, builders);
         if (creator == null) continue;
         try {
            // requestUpgrade cria uma ordem BUILD quando o nível atual é zero e valida as regras nativas.
            building.requestUpgrade(player, creator.getPosition());
            if (releaseOrderAt(colony, pos)) {
               RemoteColonyManager.LOGGER.info("[RCM] Ordem BUILD criada automaticamente para {}", pos);
            }
         } catch (Exception ex) {
            RemoteColonyManager.LOGGER.error("[RCM] Falha ao criar ordem automática para {}", pos, ex);
         }
      }
   }

   private static String buildingName(IBuilding building) {
      try {
         return building.getBuildingType().getRegistryName().getPath().replace('_', ' ');
      } catch (Exception var2) {
         return "Prédio";
      }
   }

   private static String namesOf(BuildingBuilder builder) {
      StringBuilder names = new StringBuilder();
      for (ICitizenData citizen : builder.getAllAssignedCitizen()) {
         if (names.length() > 0) names.append(", ");
         names.append(citizen.getName());
      }
      return names.toString();
   }

   private static void sendData(ServerPlayer player, IColony colony, boolean open, boolean ensure) {
      if (ensure) {
         ensurePendingBuildOrders(player, colony);
      }
      List<BuildingBuilder> allBuilders = getBuilders(colony);

      // ordem -> nome do(s) construtor(es) que a reivindicou
      Map<Integer, String> claimedByMap = new HashMap<>();
      for (BuildingBuilder b : allBuilders) {
         if (b.hasWorkOrder()) {
            IBuilderWorkOrder wo = b.getWorkOrder();
            if (wo != null) {
               String names = namesOf(b);
               if (names.isEmpty()) names = "Construtor #" + b.getBuildingLevel();
               claimedByMap.put(wo.getID(), names);
            }
         }
      }

      List<OrderEntry> orders = new ArrayList<>();
      for (IServerWorkOrder raw : colony.getWorkManager().getWorkOrders().values()) {
         if (raw instanceof IBuilderWorkOrder order) {
            boolean free = !order.isClaimed();
            String claimed = free ? "Livre" : claimedByMap.getOrDefault(order.getID(), "Atribuído");
            orders.add(new OrderEntry(
               order.getID(),
               order.getDisplayName().getString(),
               WorkOrderTypeNames.code(order.getWorkOrderType()),
               order.getLocation().asLong(),
               free,
               claimed
            ));
         }
      }
      orders.sort(Comparator.comparingInt(o -> o.id));

      List<BuilderEntry> builders = new ArrayList<>();
      int freeBuildersCount = 0;
      for (BuildingBuilder builder : allBuilders) {
         String names = namesOf(builder);
         boolean worker = !names.isEmpty();
         boolean free = !builder.hasWorkOrder();
         if (free && worker) freeBuildersCount++;
         int orderId = -1;
         if (builder.hasWorkOrder() && builder.getWorkOrder() != null) {
            orderId = builder.getWorkOrder().getID();
         }
         builders.add(new BuilderEntry(builder.getPosition().asLong(), names, free, worker, builder.getBuildingLevel(), orderId));
      }

      List<BuildingEntry> buildings = new ArrayList<>();
      int pendingBuilds = 0;
      for (IBuilding building : colony.getServerBuildingManager().getBuildings().values()) {
         BlockPos pos = building.getPosition();
         int level = getUpdatedBuildingLevel(building);
         boolean hasOrder = hasOrderAt(colony, pos);
         boolean built = building.isBuilt() || level > 0;
         if (!built && !hasOrder) pendingBuilds++;
         int flags = (built ? BuildingEntry.F_BUILT : 0) | (hasOrder ? BuildingEntry.F_ORDER : 0);
         buildings.add(new BuildingEntry(pos.asLong(), buildingName(building), level, flags));
      }
      buildings.sort(Comparator.comparing(b -> b.name.toLowerCase()));

      int citizenCount = 0;
      try {
         citizenCount = colony.getCitizenManager().getCitizens().size();
      } catch (Exception ignored) {}

      CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
         new ColonyDataPacket(open, Autopilot.isEnabled(player), Autopilot.isQueueEnabled(player), colony.getName(), orders, builders, buildings, citizenCount, freeBuildersCount, pendingBuilds));
   }

   private static BuildingBuilder findBuilder(List<BuildingBuilder> builders, long pos) {
      for (BuildingBuilder b : builders) {
         if (b.getPosition().asLong() == pos) {
            return b;
         }
      }

      return null;
   }

   private static boolean canAssign(IBuilderWorkOrder order, BuildingBuilder builder) {
      return order != null
         && builder != null
         && !order.isClaimed()
         && !builder.hasWorkOrder()
         && hasWorker(builder)
         && order.canBuildIgnoringDistance(builder, builder.getPosition(), builder.getBuildingLevel());
   }

   /**
    * Escolhe o melhor construtor livre para a ordem:
    * 1) maior nível da cabana; 2) em empate, o mais próximo da ordem.
    */
   private static BuildingBuilder chooseBestBuilder(IBuilderWorkOrder order, List<BuildingBuilder> builders) {
      BuildingBuilder best = null;
      int bestLevel = -1;
      double bestDist = Double.MAX_VALUE;
      BlockPos orderPos = order.getLocation();

      for (BuildingBuilder candidate : builders) {
         if (!canAssign(order, candidate)) {
            continue;
         }

         int level = candidate.getBuildingLevel();
         double dist = orderPos.distSqr(candidate.getPosition());

         if (level > bestLevel || (level == bestLevel && dist < bestDist)) {
            best = candidate;
            bestLevel = level;
            bestDist = dist;
         }
      }

      return best;
   }

   private static boolean assignOne(IColony colony, IBuilderWorkOrder order, BuildingBuilder builder) {
      if (!canAssign(order, builder)) {
         return false;
      } else {
         builder.setWorkOrder(order);
         order.setClaimedBy(builder.getID());
         builder.markDirty();
         colony.getWorkManager().setDirty(true);
         colony.markDirty();
         return true;
      }
   }

   private static int getUpdatedBuildingLevel(IBuilding building) {
      try {
         if (building instanceof AbstractSchematicProvider provider) {
            provider.upgradeBuildingLevelToSchematicData();
         }
      } catch (Exception var2) {
         RemoteColonyManager.LOGGER.error("[RCM] Erro ao atualizar nível da construção", var2);
      }

      return building.getBuildingLevel();
   }

   /**
    * Executa uma ação (BUILD/UPGRADE/REPAIR/REMOVE) em um prédio.
    * @return null se a ordem foi criada, ou o motivo da falha.
    */
   private static String performBuildingAction(ServerPlayer player, IColony colony, BlockPos pos, String action, List<BuildingBuilder> builders) {
      IBuilding building = (IBuilding) colony.getServerBuildingManager().getBuilding(pos);
      if (building == null) {
         return "Prédio não encontrado.";
      }
      if (hasOrderAt(colony, pos)) {
         return "Esse prédio já possui uma ordem.";
      }
      WorkOrderType requestedType = switch (action) {
         case "BUILD" -> WorkOrderType.BUILD;
         case "UPGRADE" -> WorkOrderType.UPGRADE;
         case "REPAIR" -> WorkOrderType.REPAIR;
         case "REMOVE" -> WorkOrderType.REMOVE;
         default -> null;
      };
      if (requestedType == null) {
         return "Ação desconhecida.";
      }
      boolean built = building.isBuilt() || getUpdatedBuildingLevel(building) > 0;
      BuildingBuilder creator = findOrderCreator(building, requestedType, builders);
      if (creator == null) {
         return "Não há cabana de construtor com nível suficiente para essa tarefa.";
      }
      BlockPos builderPos = creator.getPosition();
      try {
         switch (action) {
            case "BUILD":
               if (built) return "Esse prédio já está construído.";
               building.requestUpgrade(player, builderPos);
               break;
            case "UPGRADE":
               if (!built) return "O prédio ainda não está construído.";
               building.requestUpgrade(player, builderPos);
               break;
            case "REPAIR":
               if (!built) return "O prédio ainda não está construído.";
               building.requestRepair(builderPos);
               break;
            case "REMOVE":
               if (!built) return "O prédio não está construído.";
               building.requestRemoval(player, builderPos);
               break;
            default:
               return "Ação desconhecida.";
         }
      } catch (Exception ex) {
         RemoteColonyManager.LOGGER.error("Erro ao executar ação remota no prédio {}", pos, ex);
         return "Erro ao solicitar a ação. Consulte o latest.log.";
      }
      if (!releaseOrderAt(colony, pos)) {
         return "O MineColonies não criou a ordem. Verifique requisitos, pesquisas e área da colônia.";
      }
      return null;
   }

   // =====================================================================
   //  Cliente -> servidor (atalhos)
   // =====================================================================

   public static void assignManual(List<Integer> ids, List<Long> positions) {
      CHANNEL.sendToServer(new AssignPacket(ids, positions, false));
   }

   public static void autoDistribute(List<Integer> ids) {
      CHANNEL.sendToServer(new AssignPacket(ids, Collections.emptyList(), true));
   }

   public static void requestBuildingAction(List<Long> positions, String action) {
      CHANNEL.sendToServer(new BuildingActionPacket(positions, action));
   }

   /** auto=true: atualização silenciosa (não reabre o painel e não cria ordens). */
   public static void refresh(boolean auto) {
      CHANNEL.sendToServer(new RefreshPacket(auto));
   }

   public static void cancelOrders(List<Integer> ids) {
      CHANNEL.sendToServer(new CancelOrdersPacket(ids));
   }

   public static void requestAutopilot(boolean enable) {
      CHANNEL.sendToServer(new AutopilotPacket(0, enable));
   }

   public static void requestAutoQueue(boolean enable) {
      CHANNEL.sendToServer(new AutopilotPacket(1, enable));
   }

   private static int readCount(FriendlyByteBuf b) {
      int n = b.readVarInt();
      if (n < 0 || n > MAX_LIST) {
         throw new IllegalArgumentException("Pacote RCM inválido");
      }
      return n;
   }

   // =====================================================================
   //  Pacotes
   // =====================================================================

   public static class OrderEntry {
      public final int id;
      public final String name;
      public final int type;
      public final long pos;
      public final boolean available;
      public final String claimedBy;

      public OrderEntry(int id, String name, int type, long pos, boolean available, String claimedBy) {
         this.id = id;
         this.name = name == null ? "" : name;
         this.type = type;
         this.pos = pos;
         this.available = available;
         this.claimedBy = claimedBy == null ? "Livre" : claimedBy;
      }
   }

   public static class BuilderEntry {
      public final long positionId;
      public final String citizens;
      public final boolean free;
      public final boolean hasWorker;
      public final int level;
      public final int orderId;

      public BuilderEntry(long id, String citizens, boolean free, boolean worker, int level, int orderId) {
         this.positionId = id;
         this.citizens = citizens;
         this.free = free;
         this.hasWorker = worker;
         this.level = level;
         this.orderId = orderId;
      }
   }

   public static class BuildingEntry {
      public static final int F_BUILT = 1;
      public static final int F_ORDER = 2;
      public final long positionId;
      public final String name;
      public final int level;
      public final int flags;

      public BuildingEntry(long id, String name, int level, int flags) {
         this.positionId = id;
         this.name = name;
         this.level = level;
         this.flags = flags;
      }

      public boolean isBuilt() {
         return (this.flags & F_BUILT) != 0;
      }

      public boolean hasOrder() {
         return (this.flags & F_ORDER) != 0;
      }
   }

   public static class ColonyDataPacket {
      public final boolean open;
      public final boolean autopilot;
      public final boolean autoQueue;
      public final String colonyName;
      public final List<OrderEntry> orders;
      public final List<BuilderEntry> builders;
      public final List<BuildingEntry> buildings;
      public final int citizenCount;
      public final int freeBuilders;
      public final int pendingBuilds;

      public ColonyDataPacket(boolean open, boolean autopilot, boolean autoQueue, String colonyName, List<OrderEntry> orders, List<BuilderEntry> builders,
                              List<BuildingEntry> buildings, int citizenCount, int freeBuilders, int pendingBuilds) {
         this.open = open;
         this.autopilot = autopilot;
         this.autoQueue = autoQueue;
         this.colonyName = colonyName == null ? "" : colonyName;
         this.orders = orders;
         this.builders = builders;
         this.buildings = buildings;
         this.citizenCount = citizenCount;
         this.freeBuilders = freeBuilders;
         this.pendingBuilds = pendingBuilds;
      }

      public static void encode(ColonyDataPacket p, FriendlyByteBuf b) {
         b.writeBoolean(p.open);
         b.writeBoolean(p.autopilot);
         b.writeBoolean(p.autoQueue);
         b.writeUtf(p.colonyName);
         b.writeVarInt(p.orders.size());
         for (OrderEntry o : p.orders) {
            b.writeVarInt(o.id);
            b.writeUtf(o.name);
            b.writeByte(o.type);
            b.writeLong(o.pos);
            b.writeBoolean(o.available);
            b.writeUtf(o.claimedBy);
         }
         b.writeVarInt(p.builders.size());
         for (BuilderEntry v : p.builders) {
            b.writeLong(v.positionId);
            b.writeUtf(v.citizens);
            b.writeBoolean(v.free);
            b.writeBoolean(v.hasWorker);
            b.writeVarInt(v.level);
            b.writeVarInt(v.orderId + 1);
         }
         b.writeVarInt(p.buildings.size());
         for (BuildingEntry v : p.buildings) {
            b.writeLong(v.positionId);
            b.writeUtf(v.name);
            b.writeVarInt(v.level);
            b.writeByte(v.flags);
         }
         b.writeVarInt(p.citizenCount);
         b.writeVarInt(p.freeBuilders);
         b.writeVarInt(p.pendingBuilds);
      }

      public static ColonyDataPacket decode(FriendlyByteBuf b) {
         boolean open = b.readBoolean();
         boolean autopilot = b.readBoolean();
         boolean autoQueue = b.readBoolean();
         String colonyName = b.readUtf();
         List<OrderEntry> orders = new ArrayList<>();
         for (int i = b.readVarInt(); i > 0; i--) {
            orders.add(new OrderEntry(b.readVarInt(), b.readUtf(), b.readByte(), b.readLong(), b.readBoolean(), b.readUtf()));
         }
         List<BuilderEntry> builders = new ArrayList<>();
         for (int i = b.readVarInt(); i > 0; i--) {
            builders.add(new BuilderEntry(b.readLong(), b.readUtf(), b.readBoolean(), b.readBoolean(), b.readVarInt(), b.readVarInt() - 1));
         }
         List<BuildingEntry> buildings = new ArrayList<>();
         for (int i = b.readVarInt(); i > 0; i--) {
            buildings.add(new BuildingEntry(b.readLong(), b.readUtf(), b.readVarInt(), b.readByte()));
         }
         int citizenCount = b.readVarInt();
         int freeBuilders = b.readVarInt();
         int pendingBuilds = b.readVarInt();
         return new ColonyDataPacket(open, autopilot, autoQueue, colonyName, orders, builders, buildings, citizenCount, freeBuilders, pendingBuilds);
      }

      public static void handle(ColonyDataPacket p, Supplier<Context> supplier) {
         Context ctx = supplier.get();
         ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> RemoteColonyScreen.openOrUpdate(p)));
         ctx.setPacketHandled(true);
      }
   }

   public static class FeedbackPacket {
      public final int kind;
      public final String text;
      public final boolean refresh;

      public FeedbackPacket(int kind, String text, boolean refresh) {
         this.kind = kind;
         this.text = text == null ? "" : text;
         this.refresh = refresh;
      }

      public static void encode(FeedbackPacket p, FriendlyByteBuf b) {
         b.writeVarInt(p.kind);
         b.writeUtf(p.text);
         b.writeBoolean(p.refresh);
      }

      public static FeedbackPacket decode(FriendlyByteBuf b) {
         return new FeedbackPacket(b.readVarInt(), b.readUtf(), b.readBoolean());
      }

      public static void handle(FeedbackPacket p, Supplier<Context> supplier) {
         Context ctx = supplier.get();
         ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> RemoteColonyScreen.onFeedback(p.kind, p.text, p.refresh)));
         ctx.setPacketHandled(true);
      }
   }

   public static class RefreshPacket {
      public final boolean auto;

      public RefreshPacket(boolean auto) {
         this.auto = auto;
      }

      public static void encode(RefreshPacket p, FriendlyByteBuf b) {
         b.writeBoolean(p.auto);
      }

      public static RefreshPacket decode(FriendlyByteBuf b) {
         return new RefreshPacket(b.readBoolean());
      }

      public static void handle(RefreshPacket p, Supplier<Context> supplier) {
         Context ctx = supplier.get();
         ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) {
               return;
            }
            if (p.auto) {
               long now = System.currentTimeMillis();
               Long last = LAST_AUTO_REFRESH.get(player.getUUID());
               if (last != null && now - last < 900L) {
                  return;
               }
               LAST_AUTO_REFRESH.put(player.getUUID(), now);
            }
            IColony colony = getPlayerColony(player);
            if (colony != null) {
               sendData(player, colony, !p.auto, !p.auto);
            }
         });
         ctx.setPacketHandled(true);
      }
   }

   public static class AutopilotPacket {
      public final int which; // 0 = piloto (atribuir), 1 = fila automática (criar ordens)
      public final boolean enable;

      public AutopilotPacket(int which, boolean enable) {
         this.which = which;
         this.enable = enable;
      }

      public static void encode(AutopilotPacket p, FriendlyByteBuf b) {
         b.writeVarInt(p.which);
         b.writeBoolean(p.enable);
      }

      public static AutopilotPacket decode(FriendlyByteBuf b) {
         return new AutopilotPacket(b.readVarInt(), b.readBoolean());
      }

      public static void handle(AutopilotPacket p, Supplier<Context> supplier) {
         Context ctx = supplier.get();
         ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
               if (p.which == 1) {
                  setAutoQueue(player, p.enable);
               } else {
                  setAutopilot(player, p.enable);
               }
            }
         });
         ctx.setPacketHandled(true);
      }
   }

   public static class AssignPacket {
      public final List<Integer> orderIds;
      public final List<Long> builderPositions;
      public final boolean automatic;

      public AssignPacket(List<Integer> ids, List<Long> positions, boolean automatic) {
         this.orderIds = new ArrayList<>(ids);
         this.builderPositions = new ArrayList<>(positions);
         this.automatic = automatic;
      }

      public static void encode(AssignPacket p, FriendlyByteBuf b) {
         b.writeBoolean(p.automatic);
         b.writeVarInt(p.orderIds.size());
         for (int id : p.orderIds) {
            b.writeVarInt(id);
         }
         b.writeVarInt(p.builderPositions.size());
         for (long pos : p.builderPositions) {
            b.writeLong(pos);
         }
      }

      public static AssignPacket decode(FriendlyByteBuf b) {
         boolean automatic = b.readBoolean();
         List<Integer> ids = new ArrayList<>();
         for (int i = readCount(b); i > 0; i--) {
            ids.add(b.readVarInt());
         }
         List<Long> positions = new ArrayList<>();
         for (int i = readCount(b); i > 0; i--) {
            positions.add(b.readLong());
         }
         return new AssignPacket(ids, positions, automatic);
      }

      public static void handle(AssignPacket p, Supplier<Context> supplier) {
         Context ctx = supplier.get();
         ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) {
               return;
            }
            IColony colony = getPlayerColony(player);
            if (colony == null) {
               return;
            }
            List<BuildingBuilder> builders = getBuilders(colony);
            int assigned = 0;
            int rejected = 0;
            if (p.automatic) {
               for (int id : p.orderIds) {
                  if (colony.getWorkManager().getWorkOrder(id) instanceof IBuilderWorkOrder order) {
                     BuildingBuilder chosen = chooseBestBuilder(order, builders);
                     if (chosen != null && assignOne(colony, order, chosen)) {
                        assigned++;
                     } else {
                        rejected++;
                     }
                  } else {
                     rejected++;
                  }
               }
            } else {
               if (p.orderIds.size() != p.builderPositions.size()) {
                  feedback(player, FB_ERROR, "Selecione a mesma quantidade de ordens e construtores.", false);
                  sendData(player, colony, false, false);
                  return;
               }
               for (int i = 0; i < p.orderIds.size(); i++) {
                  IServerWorkOrder raw = colony.getWorkManager().getWorkOrder(p.orderIds.get(i));
                  BuildingBuilder builder = findBuilder(builders, p.builderPositions.get(i));
                  if (raw instanceof IBuilderWorkOrder order && builder != null && assignOne(colony, order, builder)) {
                     assigned++;
                  } else {
                     rejected++;
                  }
               }
            }

            colony.getWorkManager().setDirty(true);
            colony.markDirty();
            int kind = rejected == 0 ? FB_OK : (assigned > 0 ? FB_WARN : FB_ERROR);
            String text = "Atribuídas: " + assigned + (rejected > 0 ? "  |  Sem construtor livre/compatível: " + rejected : "");
            feedback(player, kind, text, false);
            sendData(player, colony, false, false);
         });
         ctx.setPacketHandled(true);
      }
   }

   public static class BuildingActionPacket {
      public final List<Long> positions;
      public final String action;

      public BuildingActionPacket(List<Long> positions, String action) {
         this.positions = new ArrayList<>(positions);
         this.action = action;
      }

      public static void encode(BuildingActionPacket p, FriendlyByteBuf b) {
         b.writeUtf(p.action);
         b.writeVarInt(p.positions.size());
         for (long pos : p.positions) {
            b.writeLong(pos);
         }
      }

      public static BuildingActionPacket decode(FriendlyByteBuf b) {
         String action = b.readUtf(32);
         List<Long> positions = new ArrayList<>();
         for (int i = readCount(b); i > 0; i--) {
            positions.add(b.readLong());
         }
         return new BuildingActionPacket(positions, action);
      }

      public static void handle(BuildingActionPacket p, Supplier<Context> supplier) {
         Context ctx = supplier.get();
         ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) {
               return;
            }
            IColony colony = getPlayerColony(player);
            if (colony == null) {
               return;
            }
            List<BuildingBuilder> builders = getBuilders(colony);
            int ok = 0;
            int fail = 0;
            String firstError = null;
            for (long pos : p.positions) {
               String err = performBuildingAction(player, colony, BlockPos.of(pos), p.action, builders);
               if (err == null) {
                  ok++;
               } else {
                  fail++;
                  if (firstError == null) firstError = err;
               }
            }
            colony.markDirty();
            if (p.positions.size() == 1) {
               if (ok == 1) {
                  feedback(player, FB_OK, "Ordem criada e liberada para escolher o construtor na aba Obras.", false);
               } else {
                  feedback(player, FB_WARN, firstError == null ? "Falha ao criar a ordem." : firstError, false);
               }
            } else {
               int kind = fail == 0 ? FB_OK : (ok > 0 ? FB_WARN : FB_ERROR);
               String text = "Ordens criadas: " + ok + (fail > 0 ? "  |  Falhas: " + fail + " (" + firstError + ")" : "");
               feedback(player, kind, text, false);
            }
            sendData(player, colony, false, false);
         });
         ctx.setPacketHandled(true);
      }
   }

   /** Libera (unclaim) ordens selecionadas para que possam ser redistribuídas. Não remove a ordem do MineColonies. */
   public static class CancelOrdersPacket {
      public final List<Integer> orderIds;

      public CancelOrdersPacket(List<Integer> ids) {
         this.orderIds = new ArrayList<>(ids);
      }

      public static void encode(CancelOrdersPacket p, FriendlyByteBuf b) {
         b.writeVarInt(p.orderIds.size());
         for (int id : p.orderIds) {
            b.writeVarInt(id);
         }
      }

      public static CancelOrdersPacket decode(FriendlyByteBuf b) {
         List<Integer> ids = new ArrayList<>();
         for (int i = readCount(b); i > 0; i--) {
            ids.add(b.readVarInt());
         }
         return new CancelOrdersPacket(ids);
      }

      public static void handle(CancelOrdersPacket p, Supplier<Context> supplier) {
         Context ctx = supplier.get();
         ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;
            IColony colony = getPlayerColony(player);
            if (colony == null) return;

            List<BuildingBuilder> builders = getBuilders(colony);
            int released = 0;
            for (int id : p.orderIds) {
               IServerWorkOrder raw = colony.getWorkManager().getWorkOrder(id);
               if (raw instanceof IBuilderWorkOrder order && order.isClaimed()) {
                  for (BuildingBuilder builder : builders) {
                     if (builder.hasWorkOrder() && builder.getWorkOrder() != null && builder.getWorkOrder().getID() == id) {
                        builder.setWorkOrder(null);
                        builder.markDirty();
                     }
                  }
                  order.setClaimedBy(null);
                  released++;
               }
            }
            if (released > 0) {
               colony.getWorkManager().setDirty(true);
               colony.markDirty();
            }
            feedback(player, released > 0 ? FB_OK : FB_WARN, "Ordens liberadas: " + released, false);
            sendData(player, colony, false, false);
         });
         ctx.setPacketHandled(true);
      }
   }
}
