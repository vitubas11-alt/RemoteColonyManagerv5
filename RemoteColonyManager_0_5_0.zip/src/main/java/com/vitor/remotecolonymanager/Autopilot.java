package com.vitor.remotecolonymanager;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * Piloto automático: a cada 5 segundos distribui as ordens livres para o melhor construtor livre,
 * mesmo com o painel fechado. O estado fica salvo no jogador (sobrevive a relogar, reiniciar e morrer).
 */
@Mod.EventBusSubscriber(modid = RemoteColonyManager.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class Autopilot {
   private static final String KEY = "rcm_autopilot";
   private static final String KEY_QUEUE = "rcm_autoqueue";
   private static final int INTERVAL_TICKS = 100;
   private static int counter = 0;

   private Autopilot() {
   }

   public static boolean isEnabled(Player player) {
      return player.getPersistentData().getBoolean(KEY);
   }

   public static void setEnabled(Player player, boolean on) {
      if (on) {
         player.getPersistentData().putBoolean(KEY, true);
      } else {
         player.getPersistentData().remove(KEY);
      }
   }

   public static boolean isQueueEnabled(Player player) {
      return player.getPersistentData().getBoolean(KEY_QUEUE);
   }

   public static void setQueueEnabled(Player player, boolean on) {
      if (on) {
         player.getPersistentData().putBoolean(KEY_QUEUE, true);
      } else {
         player.getPersistentData().remove(KEY_QUEUE);
      }
   }

   @SubscribeEvent
   public static void onServerTick(TickEvent.ServerTickEvent event) {
      if (event.phase != TickEvent.Phase.END) {
         return;
      }
      if (++counter < INTERVAL_TICKS) {
         return;
      }
      counter = 0;
      MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
      if (server == null) {
         return;
      }
      for (ServerPlayer player : server.getPlayerList().getPlayers()) {
         boolean assign = isEnabled(player);
         boolean queue = isQueueEnabled(player);
         if (!assign && !queue) {
            continue;
         }
         try {
            int created = queue ? NetworkHandler.autoQueueStep(player) : 0;
            int n = assign ? NetworkHandler.autopilotStep(player) : 0;
            if (created > 0 || n > 0) {
               String text = (created > 0 ? "Fila automática: " + created + " ordem(ns) criada(s)" : "")
                  + (created > 0 && n > 0 ? "  |  " : "")
                  + (n > 0 ? "Piloto: " + n + " atribuída(s)" : "");
               NetworkHandler.feedback(player, NetworkHandler.FB_OK, text, true);
            }
         } catch (Exception ex) {
            RemoteColonyManager.LOGGER.error("[RCM] Falha no piloto automático", ex);
         }
      }
   }

   @SubscribeEvent
   public static void onClone(PlayerEvent.Clone event) {
      if (isEnabled(event.getOriginal())) {
         setEnabled(event.getEntity(), true);
      }
      if (isQueueEnabled(event.getOriginal())) {
         setQueueEnabled(event.getEntity(), true);
      }
   }
}
